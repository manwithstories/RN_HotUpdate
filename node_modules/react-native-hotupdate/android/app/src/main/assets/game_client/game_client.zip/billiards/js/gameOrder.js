//白球对象
function createWhite(x, y, r) {
	playerBall = {
		x: x,
		y: y,
		r: r,
		img: imgLoadArr[1],
		speedX: 0,
		speedY: 0,
		speed: 0,
		type: 0,
		num: 0,
		clear: false,
		push: 0,
		prePush: 0,
		direction: 0,
		hitMenu: 0,
		hitMenuX: 0,
		hitMenuY: 0,
		hitMenuSeleX: 0,
		hitMenuSeleY: 0,
		freePlace: 1,
		firstCra: 0,
		prePushDirection:0,
		move: function() {
			if(this.x <= ballDesk.width * 0.1167) {
				this.speedX = Math.abs(this.speedX);
			} else if(this.x >= ballDesk.width - this.r - this.r - ballDesk.width * 0.1167) {
				this.speedX = -1 * Math.abs(this.speedX);
			}
			if(this.y <= ballDesk.height * 0.0658) {
				this.speedY = Math.abs(this.speedY);
			} else if(this.y >= ballDesk.height - this.r - this.r - ballDesk.height * 0.0658) {
				this.speedY = -1 * Math.abs(this.speedY);
			}
			if(this.speedX > 0 && this.speedY >= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX -= moca * bili;
				this.speedY -= moca * (1 - bili);
				this.speedX <= 0 ? this.speedX = 0 : null;
				this.speedY <= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX > 0 && this.speedY <= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX -= moca * bili;
				this.speedY += moca * (1 - bili);
				this.speedX <= 0 ? this.speedX = 0 : null;
				this.speedY >= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX < 0 && this.speedY >= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX += moca * bili;
				this.speedY -= moca * (1 - bili);
				this.speedX >= 0 ? this.speedX = 0 : null;
				this.speedY <= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX < 0 && this.speedY <= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX += moca * bili;
				this.speedY += moca * (1 - bili);
				this.speedX >= 0 ? this.speedX = 0 : null;
				this.speedY >= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			}
			ctx.drawImage(this.img, this.x, this.y, this.r * 2, this.r * 2);
			if(this.freePlace == 1) {
				ctx.drawImage(imgLoadArr[12], this.x - this.r, this.y - this.r, this.r * 4, this.r * 4)
			}

		}
	}
	ballAllArr.push(playerBall);
}
//分数球对象
function ScoreBall(x, y, num, r, img) {
	this.x = x;
	this.y = y;
	this.r = r;
	this.speedX = 0;
	this.speedY = 0;
	this.img = img;
	this.type = 2;
	this.num = num;
	this.clear = false;
}
ScoreBall.prototype.move = function() {
	if(this.x <= ballDesk.width * 0.1167) {
		this.speedX = Math.abs(this.speedX);
	} else if(this.x >= ballDesk.width - this.r - this.r - ballDesk.width * 0.1167) {
		this.speedX = -1 * Math.abs(this.speedX);
	}
	if(this.y <= ballDesk.height * 0.0658) {
		this.speedY = Math.abs(this.speedY);
	} else if(this.y >= ballDesk.height - this.r - this.r - ballDesk.height * 0.0658) {
		this.speedY = -1 * Math.abs(this.speedY);
	}
	if(this.speedX > 0 && this.speedY > 0) {
		var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
		this.speedX -= moca * bili;
		this.speedY -= moca * (1 - bili);
		this.speedX <= 0 ? this.speedX = 0 : null;
		this.speedY <= 0 ? this.speedY = 0 : null;
		this.x += this.speedX;
		this.y += this.speedY;
	} else if(this.speedX > 0 && this.speedY < 0) {
		var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
		this.speedX -= moca * bili;
		this.speedY += moca * (1 - bili);
		this.speedX <= 0 ? this.speedX = 0 : null;
		this.speedY >= 0 ? this.speedY = 0 : null;
		this.x += this.speedX;
		this.y += this.speedY;
	} else if(this.speedX < 0 && this.speedY > 0) {
		var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
		this.speedX += moca * bili;
		this.speedY -= moca * (1 - bili);
		this.speedX >= 0 ? this.speedX = 0 : null;
		this.speedY <= 0 ? this.speedY = 0 : null;
		this.x += this.speedX;
		this.y += this.speedY;
	} else if(this.speedX < 0 && this.speedY < 0) {
		var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
		this.speedX += moca * bili;
		this.speedY += moca * (1 - bili);
		this.speedX >= 0 ? this.speedX = 0 : null;
		this.speedY >= 0 ? this.speedY = 0 : null;
		this.x += this.speedX;
		this.y += this.speedY;
	}
	ctx.drawImage(this.img, this.x, this.y, this.r * 2, this.r * 2);
}
//创建分数球
function createScoreBall(positions) {
	 var scoreBall1 = new ScoreBall(positions[0][0] * ballDesk.width / 100, positions[0][1] * ballDesk.width / 100, 1, ballDesk.width*0.04, imgLoadArr[2]);
 	var scoreBall2 = new ScoreBall(positions[1][0] * ballDesk.width / 100, positions[1][1] * ballDesk.width / 100, 2, ballDesk.width*0.04, imgLoadArr[3]);
 	var scoreBall3 = new ScoreBall(positions[2][0] * ballDesk.width / 100, positions[2][1] * ballDesk.width / 100, 3, ballDesk.width*0.04, imgLoadArr[4]);
 	var scoreBall4 = new ScoreBall(positions[3][0] * ballDesk.width / 100, positions[3][1] * ballDesk.width / 100, 4, ballDesk.width*0.04, imgLoadArr[5]);
 	var scoreBall5 = new ScoreBall(positions[4][0] * ballDesk.width / 100, positions[4][1] * ballDesk.width / 100, 5, ballDesk.width*0.04, imgLoadArr[6]);
 	var scoreBall6 = new ScoreBall(positions[5][0] * ballDesk.width / 100, positions[5][1] * ballDesk.width / 100, 6, ballDesk.width*0.04, imgLoadArr[7]);
	var scoreBall7 = new ScoreBall(positions[6][0] * ballDesk.width / 100, positions[6][1] * ballDesk.width / 100, 7, ballDesk.width*0.04, imgLoadArr[8]);
 	var scoreBall8 = new ScoreBall(positions[7][0] * ballDesk.width / 100, positions[7][1] * ballDesk.width / 100, 8, ballDesk.width*0.04, imgLoadArr[9]);
 	var scoreBall9 = new ScoreBall(positions[8][0] * ballDesk.width / 100, positions[8][1] * ballDesk.width / 100, 9, ballDesk.width*0.04, imgLoadArr[10]);
	scoreBallArr.push(scoreBall1);
	scoreBallArr.push(scoreBall2);
	scoreBallArr.push(scoreBall3);
	scoreBallArr.push(scoreBall4);
	scoreBallArr.push(scoreBall5);
	scoreBallArr.push(scoreBall6);
	scoreBallArr.push(scoreBall7);
	scoreBallArr.push(scoreBall8);
	scoreBallArr.push(scoreBall9);
	ballAllArr = ballAllArr.concat(scoreBallArr);
}
//球洞
//创建进洞球
function CoreBall(x, y) {
	this.x = x;
	this.y = y;
	this.r = ballDesk.width * 0.05;
	this.type = 10;
}
CoreBall.prototype.move = function() {
	ctx.beginPath();
	ctx.fillStyle = "red";
	ctx.arc(this.x + this.r, this.y + this.r, this.r, 0, Math.PI * 2, false);
	ctx.fill();
}

function createCoreBall() {
	// 创建六个分数球
	var ball_core_1 = new CoreBall(ballDesk.width * 0.06555, ballDesk.width * 0.07666);
	var ball_core_2 = new CoreBall(ballDesk.width * 0.83444, ballDesk.width * 0.07666);
	var ball_core_3 = new CoreBall(ballDesk.width * 0.04555, ballDesk.height * 0.5 - ballDesk.width * 0.05);
	var ball_core_4 = new CoreBall(ballDesk.width * 0.85444, ballDesk.height * 0.5 - ballDesk.width * 0.05);
	var ball_core_5 = new CoreBall(ballDesk.width * 0.06555, ballDesk.height - ballDesk.width * 0.17666);
	var ball_core_6 = new CoreBall(ballDesk.width * 0.83444, ballDesk.height - ballDesk.width * 0.17666);
	scoreBalls.push(ball_core_1);
	scoreBalls.push(ball_core_2);
	scoreBalls.push(ball_core_3);
	scoreBalls.push(ball_core_4);
	scoreBalls.push(ball_core_5);
	scoreBalls.push(ball_core_6);
}

//击球时间
function hitFunc(){
	ballDesk.canHit = true;
	ballDesk.addEventListener("touchend",function(e){
		e.preventDefault();
		if(ballDesk.canHit == true && ballDesk.canDrawLine == true && e.touches.length == 0 && playerBall.freePlace == 0 && master == 1){
			playerBall.push = playerBall.prePush;
			var disX = this.x - playerBall.r - playerBall.x;
			var disY = this.y - playerBall.r - playerBall.y;
			var direc = angle(0, 0, -disX, -disY);
			var speedAuto = 5 + 20 * (disDis/(playerBall.r*6));
			playerBall.speedX = speedAuto * Math.cos(direc * Math.PI / 180);
			playerBall.speedY = speedAuto * Math.sin(direc * Math.PI / 180);
			ballDesk.canDrawLine = false;
			ballDesk.canHit = false;
			ballDesk.min = returnMinNum();
			preScoreNum = ballIn.length;
		};
		if(ballDesk.canHit == true && ballDesk.canDrawLine == true && e.touches.length == 1 && playerBall.freePlace == 0) {
			playerBall.hitMenu = 0;
		};
		var num = 0;
		//摆球位置
		if(playerBall.freePlace == 1){
			for(var i = 1 ; i < ballAllArr.length;i++){
			var dis = Math.sqrt((ballAllArr[i].x - playerBall.x)*(ballAllArr[i].x - playerBall.x) + (ballAllArr[i].y - playerBall.y)*(ballAllArr[i].y - playerBall.y));
			if(dis > playerBall.r*1.6){
				num ++ ;
			}
		}
			for(var i = 0 ; i < scoreBalls.length;i++){
			var dis = Math.sqrt((scoreBalls[i].x - playerBall.x)*(scoreBalls[i].x - playerBall.x) + (scoreBalls[i].y - playerBall.y)*(scoreBalls[i].y - playerBall.y));
			if(dis > playerBall.r*2){
				num ++ ;
			}
		}
		if(num == ballAllArr.length +5) {
			playerBall.freePlace = 0;
			ballDesk.canDrawLine = false;
			crashClear = [];
		}
		}
	},false);
}
//创建绘制参考线的事件
function makeTipLine(){
	ballDesk.canDrawLine = false;
	ballDesk.addEventListener("touchstart", function(e) {
		e.preventDefault();
		if(ballDesk.canHit == true ) {
//			gameTimer = requestAnimationFrame(render);
			ballDesk.canDrawLine = true;
			this.x = e.touches[0].clientX * scale[0];
			this.y = e.touches[0].clientY * scale[0];
			this.preX = e.touches[0].clientX * scale[0];
			this.preY = e.touches[0].clientY * scale[0];
			caculateBechange = true;
		}
	}, false);
	ballDesk.addEventListener("touchmove", function(e) {
//		gameTimer = requestAnimationFrame(render);
		e.preventDefault();
		caculateBechange = true;
		this.x = e.touches[0].clientX*scale[0] - ballDesk.offsetLeft;
		this.y = e.touches[0].clientY*scale[0] - ballDesk.offsetTop;
		if(playerBall.freePlace == 1) {
			playerBall.x = e.touches[0].clientX*scale[0] - playerBall.r - ballDesk.offsetLeft * 2;
			playerBall.y = e.touches[0].clientY*scale[0] - playerBall.r - ballDesk.offsetTop * 2;
			if(playerBall.x <= ballDesk.width * 0.1167) {
				playerBall.x = ballDesk.width * 0.1167;
			} else if(playerBall.x >= ballDesk.width - playerBall.r - playerBall.r - ballDesk.width * 0.1167) {
				playerBall.x = ballDesk.width - playerBall.r - playerBall.r - ballDesk.width * 0.1167;
			}
			if(playerBall.y <= ballDesk.height * 0.0658) {
				playerBall.y = ballDesk.height * 0.0658;
			} else if(playerBall.y >= ballDesk.height - playerBall.r - playerBall.r - ballDesk.height * 0.0658) {
				playerBall.y = ballDesk.height - playerBall.r - playerBall.r - ballDesk.height * 0.0658;
			}
		}
	}, false);

	
}
function drawTipLine(){
	var num = 0;
	var len = ballAllArr.length;
	for(var i = 0 ; i < len; i ++){
		if(ballAllArr[i].speedX == 0 && ballAllArr[i].speedY == 0 && ballDesk.canHit == false){
			num++;
		}
	}
	if(num == len && ganAnimate == false) {
		//单次挥杆结束
		allMove = false;
		ballDesk.canHit =true;
		if(playerBall.firstCra == 0) {
			console.log("没碰到球");
			game = false;
			tip = "没有碰到球，加把力试试看！"
		}
		if(preScoreNum == ballIn.length && playerBall.firstCra != 0) {
			console.log("没有球进");
			game = false;
			tip = "很遗憾没有进球"
		}
		if(playerBall.firstCra != 0 && playerBall.firstCra != ballDesk.min) {
			console.log("游戏结束");
			game = false;
			tip = "请保证母球率先碰到场上最小球才算击球成功"
		}
		if(playerBall.firstCra == ballDesk.min && (preScoreNum+1) < ballIn.length){
			var muqiu = 0;
			for(var i = 0 ; i < ballIn.length ; i ++){
				if(ballIn[i] == 0){
					muqiu = 1;
//					game = false;
//					break;
				}
			}
			addScore += ((ballIn.length - preScoreNum-1)*10 - muqiu*10);
			(function(){
				scoreAll = 5;
				for(var i = 0; i < ballIn.length; i++) {
					scoreAll += parseInt(ballIn[i]);
					if(ballIn[i] == 0){
						game = false;
					}
				}
				if(ballIn.length == 9){
					game = false;
				}
		//		scoreAll >=50 ?(function(){scoreAll = 50 + (9-gameNumControl)*10})():null;
				console.log(addScore);
				scoreAll += addScore;
				var scoreDiv = document.querySelector(".score");
				var _preScore = preScore;
				clearInterval(animateTimer);
				ballInlen = ballIn.length;
				animateTimer =  setInterval(function(){
					if(_preScore == scoreAll){
						clearInterval(animateTimer);
						setTimeout(function(){
							scoreDiv.innerHTML = "得分：" + scoreAll;
						},0);
						preScore = scoreAll;
					}else {
						_preScore ++;
						setTimeout(function(){
							scoreDiv.innerHTML = "得分：" + _preScore;
						},0)
					}
				},100)
			})();
		}
		playerBall.firstCra = 0;
		if(game == false){
//			console.log("游戏结束")
			gameEnd();
		}
	}
	if(ballDesk.canDrawLine == true && playerBall.freePlace == 0 || ganAnimate == 1) {
//		console.log(1);//需改善！
		ctx.moveTo(ballDesk.x, ballDesk.y);
		ctx.strokeStyle = "red";
		ctx.fillStyle = "#55A07B";
//		console.log(caculateBechange);
		if(caculateBechange == true){
			var arr = calculate();
			caculateCache[0] = arr[0];
			caculateCache[1] = arr[1];
			caculateCache[2] = arr[2];
//			console.log(2);
		}else {
//			console.log(1);
			var arr = [];
			arr[0] = caculateCache[0];	
			arr[1] = caculateCache[1];
			arr[2] = caculateCache[2];
		}
		ctx.stroke();
		drawDot(arr[0], arr[1],arr[2]);
		ctx.moveTo(arr[0] + playerBall.r, arr[1]);
		ctx.arc(arr[0], arr[1], ballDesk.width*0.04 * 0.8, 0, Math.PI * 2, false);
		ctx.fill();
		ctx.save();
		ctx.translate(playerBall.x + playerBall.r, playerBall.y + playerBall.r);
		var dire = angle(playerBall.x + playerBall.r, playerBall.y + playerBall.r, arr[0], arr[1]) + 90;
		ctx.rotate(dire * Math.PI / 180);
		ctx.drawImage(imgLoadArr[13], -playerBall.r * 0.42, disDis, playerBall.r * 0.84, playerBall.r * 26.5);
		ctx.restore();
		caculateBechange = false;
	}
}
function calculate() {
	var bili = Math.abs((playerBall.x + playerBall.r - ballDesk.x) / (playerBall.y + playerBall.r - ballDesk.y));
	var sqrt = Math.sqrt(1 + bili * bili);
	var sinx = (bili / sqrt) * (playerBall.x + playerBall.r - ballDesk.x) / Math.abs(playerBall.x + playerBall.r - ballDesk.x) || 0;
	var siny = 1 / sqrt * (playerBall.y + playerBall.r - ballDesk.y) / Math.abs(playerBall.y + playerBall.r - ballDesk.y);
	var oriX = playerBall.x + playerBall.r;
	var oriY = playerBall.y + playerBall.r;
	if(playerBall.y + playerBall.r - ballDesk.y == 0) {
		if(playerBall.x + playerBall.r >= ballDesk.x) {
			sinx = 1;
			siny = 0;
		} else {
			sinx = -1;
			siny = 0;
		}
	}
	sinx *= 3;
	siny *= 3;
	while(oriX < ballDesk.width && oriY < ballDesk.height && oriX > playerBall.r && oriY > playerBall.r) {
		oriX += sinx;
		oriY += siny;
		for(var i = 1; i < ballAllArr.length; i++) {
			var spaceDis = Math.sqrt((oriX - ballAllArr[i].x - ballAllArr[i].r) * (oriX - ballAllArr[i].x - ballAllArr[i].r) + (oriY - ballAllArr[i].y - ballAllArr[i].r) * (oriY - ballAllArr[i].y - ballAllArr[i].r));
			if(spaceDis < (ballAllArr[i].r + playerBall.r) * 0.8) {
				var dire = angle(ballAllArr[i].x + ballAllArr[i].r,ballAllArr[i].y+ballAllArr[i].r,oriX,oriY);
				return [oriX, oriY,dire+180];
			}
//			if(oriX > ballDesk.width - playerBall.r - ballDesk.width * 0.1167 || oriY > ballDesk.height - playerBall.r - ballDesk.height * 0.0658 || oriX < playerBall.r + ballDesk.width * 0.1167 || oriY < playerBall.r + ballDesk.height * 0.0658) {
//				return [oriX, oriY];
//			}
			if(oriX > ballDesk.width - playerBall.r - ballDesk.width * 0.1167 || oriX < playerBall.r + ballDesk.width * 0.1167){
				var dire = angle(0,0,-sinx,siny);
				return [oriX,oriY,dire];
			}
			if(oriY > ballDesk.height - playerBall.r - ballDesk.height*0.0658 || oriY < playerBall.r + ballDesk.width * 0.1167){
				var dire = angle(0,0,sinx,-siny);
				return [oriX,oriY,dire];
			}
		}
	}
}

function angle(x1, y1, x2, y2) {
	var diff_x = x2 - x1,
		diff_y = y2 - y1;
	//返回角度,不是弧度
	if(diff_x < 0) {
//		diff_x == 0?diff_x = 0:null;
		return 360 * Math.atan(diff_y / diff_x) / (2 * Math.PI) + 180;
	} else {
		diff_x == 0?diff_x = 0:null;
		return 360 * Math.atan(diff_y / diff_x) / (2 * Math.PI);
	}
}

function drawDot(a, b,c) {
	var dotArr = [];
	var dis = Math.sqrt((a - playerBall.x - playerBall.r) * (a - playerBall.x - playerBall.r) + (b - playerBall.y - playerBall.r) * (b - playerBall.y - playerBall.r));
	var lineDire = angle(playerBall.x + playerBall.r, playerBall.y + playerBall.r, a, b);
	var dotdis = 70*xxxxx;
	var num = parseInt(dis / dotdis);
	for(var i = 1; i < num; i++) {
		ctx.beginPath();
		ctx.fillStyle = "#55A07B";
		ctx.arc((playerBall.x + playerBall.r + dotdis * i * Math.cos(lineDire * Math.PI / 180)), (playerBall.y + playerBall.r + dotdis * i * Math.sin(lineDire * Math.PI / 180)), 5, 0, Math.PI * 2, false);
		ctx.fill();
		ctx.closePath();
	}
	for(var i = 2; i < 8;i++){
		ctx.beginPath();
		ctx.fillStyle = "#55A07B";
		ctx.arc((a+dotdis*i*Math.cos(c*Math.PI/180)),(b+dotdis*i*Math.sin(c*Math.PI/180)),5,0,Math.PI*2,false);
		ctx.fill();
		ctx.closePath();
	}
}

function score() {
	if(ballInlen != ballIn.length && game == true && playerBall.firstCra == ballDesk.min) {
		scoreAll = 5;
		for(var i = 0; i < ballIn.length; i++) {
			scoreAll += parseInt(ballIn[i]);
			if(ballIn[i] == 0){
				game = false;
			}
		}
		if(ballIn.length == 9){
			game = false;
		}
//		scoreAll >=50 ?(function(){scoreAll = 50 + (9-gameNumControl)*10})():null;
		console.log(addScore);
		scoreAll += addScore;
		var scoreDiv = document.querySelector(".score");
		var _preScore = preScore;
		clearInterval(animateTimer);
		ballInlen = ballIn.length;
		animateTimer =  setInterval(function(){
			if(_preScore == scoreAll){
				clearInterval(animateTimer);
				setTimeout(function(){
					scoreDiv.innerHTML = "得分：" + scoreAll;
				},0);
				preScore = scoreAll;
			}else {
				_preScore ++;
				setTimeout(function(){
					scoreDiv.innerHTML = "得分：" + _preScore;
				},0)
			}
		},100)
	}
}

function returnMinNum() {
	var min = 10;
	for(var i = 1; i < ballAllArr.length; i++) {
		ballAllArr[i].num <= min ? min = ballAllArr[i].num : null;
	}
	return min;
}
function restart(){
	location.reload();
}
//碰撞检测
function jugeCrash(obj1, obj2) {
	var spaceBall = Math.sqrt((obj1.x - obj2.x) * (obj1.x - obj2.x) + (obj1.y - obj2.y) * (obj1.y - obj2.y));
	var canCrash = true;
	var index = -1;
	for(var l = 0; l < crashClear.length; l++) {
		if(crashClear[l][0] == obj1.num && crashClear[l][1] == obj2.num) {
			canCrash = false;
			index = l;
		}
	}
	if(spaceBall < (obj1.r + obj2.r) * 0.9 && canCrash == true) {
		if(obj1.speedX != 0 || obj2.speedX !=0 || obj2.speedX != 0 || obj2.speedY != 0){
			setPosition(obj1,obj2);
		}		
		crashClear.push([obj1.num, obj2.num]);
		//撞了！！
		var v1x = obj1.speedX;
		var v1y = obj1.speedY;
		var v2x = obj2.speedX;
		var v2y = obj2.speedY;
		var x1 = obj1.x;
		var x2 = obj2.x;
		var y1 = obj1.y;
		var y2 = obj2.y;
		var addx = ((v1x - v2x) * (x1 - x2) * (x1 - x2) + (v1y - v2y) * (x1 - x2) * (y1 - y2)) / ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
		var addy = ((v1y - v2y) * (y1 - y2) * (y1 - y2) + (v1x - v2x) * (x1 - x2) * (y1 - y2)) / ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
		obj1.speedX = v1x - addx;
		obj1.speedY = v1y - addy;
		obj2.speedX = v2x + addx;
		obj2.speedY = v2y + addy;
		if(obj1.num == 0 && obj1.freePlace == 0 && playerBall.push != 0) {
			playerBall.direction = angle(0, 0, playerBall.speedX, playerBall.speedY);
			playerBall.speed = Math.sqrt(playerBall.speedX * playerBall.speedX + playerBall.speedY * playerBall.speedY);
			playerBall.prespeed = Math.sqrt(v1x * v1x + v1y * v1y);
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					playerBall.speedX += -1*0.6*v1x*Math.sin(playerBall.prePushDirection*Math.PI/180)*playerBall.push;
					playerBall.speedY += -1*0.6*v1y*Math.sin(playerBall.prePushDirection*Math.PI/180)*playerBall.push;
					
					playerBall.speed = Math.sqrt(playerBall.speedX * playerBall.speedX + playerBall.speedY * playerBall.speedY);
					playerBall.direction = angle(0, 0, playerBall.speedX, playerBall.speedY);
					if(Math.sin(playerBall.prePushDirection*Math.PI/180) < 0){
//						alert(1);
						playerBall.direction += playerBall.push*Math.cos(playerBall.prePushDirection*Math.PI/180)*30;
					}else {
						playerBall.direction -= playerBall.push*Math.cos(playerBall.prePushDirection*Math.PI/180)*30;
					}
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
			
		}
		playerBall.push = 0;
		playerBall.prePushDirection = 0;
		playerBall.firstCra == 0 ? playerBall.firstCra = obj2.num : null;
	} else if(spaceBall > (obj1.r + obj2.r) && canCrash == false) {
		crashClear.splice(index, 1);
	}
}
//位置纠正
function setPosition(obj1,obj2){
	var speedx = obj1.speedX/10;
	var speedy = obj1.speedY/10;
	var speedxx = obj2.speedX/10;
	var speedyy = obj2.speedY/10;
	var dis = Math.sqrt((obj1.x - obj2.x)*(obj1.x-obj2.x)+(obj1.y-obj2.y)*(obj1.y-obj2.y));
	while(dis <= (obj1.r + obj2.r)*0.8 ){
		obj1.x -= speedx;
		obj1.y -= speedy;
		obj2.x -= speedxx;
		obj2.y -= speedyy;
		dis = Math.sqrt((obj1.x - obj2.x)*(obj1.x-obj2.x)+(obj1.y-obj2.y)*(obj1.y-obj2.y));
	}
}
//判断所有球碰撞
function judgeCrashAll(){
	for(var i = 0 ; i < ballAllArr.length; i ++){
		if(ballAllArr[i].clear == true){
			ballAllArr.splice(i,1);
			i--;
		}
	}
	for(var i = 0 ; i < ballAllArr.length; i ++){
		for(var j = i + 1 ; j < ballAllArr.length; j ++){
			jugeCrash(ballAllArr[i],ballAllArr[j]);
		}
	}
}
//判断进洞
function getScore() {
	for(var i = 0; i < ballAllArr.length; i++) {
		for(var j = 0; j < scoreBalls.length; j++) {
			var obj1 = ballAllArr[i];
			var obj2 = scoreBalls[j];
			var spaceBall = Math.sqrt((obj1.x - obj2.x) * (obj1.x - obj2.x) + (obj1.y - obj2.y) * (obj1.y - obj2.y));
			if(spaceBall <= (obj2.r + obj1.r)*0.9 && playerBall.freePlace == 0 && obj1.clear == false && gameNumControl != 0) {
				obj1.clear = true;
				occBall(obj1,j);
				ballIn.push(obj1.num);
			}
		}
	}
}
function occBall(ballobj,holeNum){
	var obj = {
		rrr:60,
		ball:ballobj,
		holeNum:holeNum,
		occ:true,
	};
	obj.timer = setInterval(function(){
			getscorestatus = true;
			obj.rrr -= 2;
			if(obj.rrr <= 0) {
				clearInterval(obj.timer);
				obj.timer = null;
				obj.occ = false;
				getscorestatus = false;
			}
		},25);
	animateBall.push(obj);
	
}
var animateBall = [];
function occ(){
	for(var i = 0 ; i < animateBall.length ; i ++){
		if(animateBall[i].occ == true){
			ctx.drawImage(animateBall[i].ball.img,scoreBalls[animateBall[i].holeNum].x+scoreBalls[animateBall[i].holeNum].r-animateBall[i].rrr,scoreBalls[animateBall[i].holeNum].y+scoreBalls[animateBall[i].holeNum].r-animateBall[i].rrr,animateBall[i].rrr*2,animateBall[i].rrr*2);
		}
	}
}

