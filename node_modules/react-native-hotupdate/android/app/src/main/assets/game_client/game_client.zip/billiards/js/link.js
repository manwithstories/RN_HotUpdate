function createGame(){
		preLoading();
}
//游戏结束
function gameEnd() {
	if(game == false && submitScore == true) {
		var winning = "";
//		if(scoreAll == 50){
//			winning = "on";
//		}
//		var add = 0;
//		for(var i = 0 ; i < ballIn.length ; i ++){
//			add += ballIn[i];
//		}
//		if(add == 45){
//			winning = "on";
//		}
//		add+=addScore;
		console.log(scoreAll);
		loadXMLDoc("POST",'/game_server/billiards/'+gameId+'/submit_score/',function(data){
			clearInterval(gameTimer);
			var result = JSON.parse(data);
			loadXMLDoc("GET",'/game_server/billiards/'+gameId+'/rank_week/',function(data){
				var result1 = JSON.parse(data);
				if(result1.ok == true){
					var best_score_player = result1.obj.user_best_score;
					var scoreNow = result1["obj"]["score"];
					var rankData = result1 ["obj"]["rank"];
					document.querySelector(".gameEnd_header").innerHTML = '<p>游戏结束</p><p>本局得分：'+scoreNow+'</p><p>奖励'+scoreNow+'积分</p>';
					document.querySelector(".bestScore").innerHTML = "你的最好成绩："+best_score_player;
					var rank_content = document.querySelector(".rank_content");
					var strHTML = "";
					for(var i = 0 ; i < rankData.length ; i ++){
						
						var str = '<div class="rankCell"><span>'+(i+1)+'</span><span>'+rankData[i]["name"]+'</span><span>'+rankData[i]["best_score"]+'</span></div>'
						strHTML += str;
					}
					rank_content.innerHTML = strHTML;
					document.querySelector(".gameEnd").style.display = "block";												
				}else {
					alert(data);
				}				
			},{});		
                        if (result.ok != true) {
                            alert(data);
                        }                      
		},{
			winning: winning,
          	score:scoreAll,
          	replay: ""
		})
		submitScore = false;
	}	
}
function setGame(position){
//	function(){
			createWhite(ballDesk.width*0.2,ballDesk.width*0.2,ballDesk.width*0.04);//创建母球对象
			createScoreBall(position);//创建得分球
			createCoreBall();//创建球洞
			stopped = false;
//			gameTimer = requestAnimationFrame(render);
			gameTimer = setInterval(function(){
				setTimeout(render,0)
			},25);
}
function render(){
				if (!stopped){
					ctx.clearRect(0,0,ballDesk.width,ballDesk.height);
					ctx.beginPath();
					if(playerBall.freePlace  == 0){
						judgeCrashAll();
					}
					getScore();
//					score();
					for(var i = 0 ; i < ballAllArr.length;i++){
						ballAllArr[i].move();
					}
//					for(var i = 0 ; i < scoreBalls.length;i++){
//						ctx.beginPath();
//						ctx.fillStyle = "red";
//						ctx.arc(scoreBalls[i].x+scoreBalls[i].r,scoreBalls[i].y+scoreBalls[i].r,scoreBalls[i].r,0,Math.PI*2,false);
//						ctx.fill();
//					}
					//绘制提示线
					drawTipLine();
					score();
					//绘制球洞
						occ();
					ctx.closePath();
//					gameEnd();
					judeAnimate();
//					gameTimer = requestAnimationFrame(render);
//					console.log(stoped);
				}else {
					judeAnimate();
//					gameTimer = requestAnimationFrame(render);
				}
			}
//重新开始游戏
function restart(){
	location.reload();
}
//返回场上最小的球判断击球是否有效
function returnMinNum() {
	var min = 10;
	for(var i = 1; i < ballAllArr.length; i++) {
		ballAllArr[i].num <= min ? min = ballAllArr[i].num : null;
	}
	return min;
}
function begin(){
	if(commit == false){
		commit = true;
		loadXMLDoc("POST",'/game_server/billiards/create_game/', function(data){
		var result = JSON.parse(data);
		if(result["ok"] == true){
			gameId = result.game.id;
			document.querySelector(".menu").style.display = "none";
			setGame(result.init_positions);
		}else if(result["error"] == "not_enough_qqi" || result["error"] == "paid_fail") {
			occMessage(result["msg"]);
			commit = false;
		}
	},{})
	}
}
function test(){
	document.querySelector(".menu").style.display = "none";
	setGame([[30,30],[30,50],[30,80],[30,110],[50,30],[50,50],[50,80],[50,110],[75,25]]);
}

function exit_per(){
	document.querySelector(".exitTip").style.display = "block"
}
function continueGame(){
	document.querySelector(".exitTip").style.display = "none"
}
function menuRankContent(){
	loadXMLDoc("GET",'/game_server/billiards/rank_no_user/',function(data){
				var result1 = JSON.parse(data);
				if(result1.ok == true){
					var rankData = result1 ["obj"]["rank"];
					var rank_content = document.querySelector(".menu_rank_content");
					var strHTML = "";
					for(var i = 0 ; i < rankData.length ; i ++){
						var str = '<div class="rankCell"><span>'+(i+1)+'</span><span>'+rankData[i]["name"]+'</span><span>'+rankData[i]["best_score"]+'</span></div>';
						
						strHTML += str;
					}
					rank_content.innerHTML = strHTML;
					setTimeout(function(){
						document.querySelector(".menu").style.display = "none";
						document.querySelector(".menuRank").style.display = "block";
					},0)
				}else {
					alert(data);
				}				
			},{});	
}
function returnMenu(){
	document.querySelector(".menuRank").style.display = "none";
	document.querySelector(".menu").style.display = "block";
}
function judeAnimate(){
	if(allMove == false && ballDesk.canHit == true && getscorestatus == false && dragstatus == false && ganAnimate == false && playerBall.freePlace == 0 && caculateBechange == false){
		stopped = true;
	}else {
		stopped = false;
	}
}
function occMessage(str){
	var message = document.querySelector(".message");
	message.opacity = 0;
	message.innerHTML = str;
	setTimeout(function(){
		message.style.display = "block";
	},false)
	message.speed = 0.05;
	message.timer = requestAnimationFrame(render_message);
	function render_message(){
		if(message.opacity <= 1 && message.speed >= 0){
			message.opacity += message.speed;
			message.style.opacity = message.opacity;
			message.timer = requestAnimationFrame(render_message);
		}else {
			setTimeout(function(){
				message.style.display = "none";
				message.style.opacity = 0;
			},200)
		}
	}
}
