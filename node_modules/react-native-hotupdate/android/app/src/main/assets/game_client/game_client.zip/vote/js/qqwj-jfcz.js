if (!qqwj)
{
	var qqwj = {};

	qqwj.Utils = {

		isMobile: /(mobile|iphone|ipod|ipad|ios|android|windows phone)/i.test(navigator.userAgent),
		isAndroid: /android/i.test(navigator.userAgent),
		isWeixin: /MicroMessenger/i.test(navigator.userAgent),

		isNullOrUndefined: function(value) {
			if (typeof(value) === "undefined" ||
				value === null || value === "")
			{
				return true;
			}
		},

		getUrlParam: function(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
            var r = window.location.search.substr(1).match(reg);  //匹配目标参数
            if (r != null) return unescape(r[2]); return null; //返回参数值
       },

		getPointDistance: function(p1, p2) {
			return Math.floor(Math.sqrt(Math.floor(Math.pow(p1.x - p2.x, 2)) + Math.floor(Math.pow(p1.y - p2.y, 2))));
		}

	};

	qqwj.Event = {

		_eventMap: {
			click: "touchstart",
			mousedown: "touchstart",
			mouseup: "touchend"
		},

		addEvent: function(ele, eventName, func, useCapture) {
			var u = qqwj.Utils;
			if (ele == null)
			{
				return;
			}
			ele.addEventListener ? 
				ele.addEventListener(u.isMobile ? qqwj.Event._eventMap[eventName] || eventName : eventName, func, useCapture) : 
				ele.attachEvent ? ele.attachEvent("on" + eventName, func) : ele["on" + eventName] = func
		},

		stopEvent: function(e) {
			e && (e.preventDefault ? (e.preventDefault(), e.stopPropagation()) : (e.returnValue = !1, e.cancelBubble = !0))
		}

	};

	qqwj.UserEvent = {

		_eventList: {},

		_isFunction: function(func) {
			return "function" === Object.prototype.toString.call(func).slice(8, -1).toLowerCase();
		},

		add: function(event, func) {
			if (this._isFunction(func))
			{
				var e = this._eventList;
				event = event.toLowerCase(), !e[event] && (e[event] = []),
					e[event].push(func);
			}
		},

		remove: function(event, func) {
			event = event.toLowerCase();
			var e, f = this._eventList[event];
			if (this._isFunction(func) && f && f.length)
			{
				for (e = f.length - 1; e >= 0; e--)
				{
					f[e] === func && f.splice(e, 1);
				}
			}
		},

		fire: function(event) {
			event = event.toLowerCase();
			var d, e, f, g;
			if (event = event.toLowerCase(), d = this._eventList[event], d && d.length)
			{
				for (e = Array.prototype.slice.call(arguments, 1), g = d.length, f = 0; g > f; f++)
				{
					d[f].apply({}, e);
				}
			}
		}

	};
}

if (!qqwj.game)
{
	qqwj.game = {};

	qqwj.game.DrawUtils = {

		drawCircle: function(ctx2d, x, y, r, c) {
			ctx2d.beginPath();
			ctx2d.arc(x, y, r, 0, 2 * Math.PI, !1);
			ctx2d.fillStyle = c || "black";
			ctx2d.fill();
		},

		drawLine: function(ctx2d, x1, y1, x2, y2, c, w)
		{
			ctx2d.strokeStyle = c || "black";
			ctx2d.lineWidth = w || 1;
			ctx2d.beginPath();
			ctx2d.moveTo(x1, y1);
			ctx2d.lineTo(x2, y2);
			ctx2d.stroke();
		},

		drawText: function(ctx2d, x, y, s, w, c)
		{
			ctx2d.font = w + "px Helvetica";
			ctx2d.fillStyle = c || "black";
			ctx2d.fillText(s, x, y);
		},

		getTextWidth: function(ctx2d, x, y, s, w, c)
		{
			ctx2d.font = w + "px Helvetica";
			ctx2d.fillStyle = c || "black";
			return ctx2d.measureText(s).width;
		}

	};
}

function _a(speed, direction) {
	return function () {
		var c = 0;
		return function () {
			return c += speed * direction % 360
		}
	}
}

function _b(a, b) {
	return function () {
		var c = 0,
			d = 1,
			e = +new Date;
		return function () {
			var f = +new Date;
			return f - e > b && (d = -d, e = f),
				c += d * a % 360
		}
	}
}

function _c(a, b, c, d) {
	return function () {
		var e = 0,
			f = +new Date;
		return function () {
			var g = +new Date;
			return g - f > c && (a = b - a, f = g),
				e += a * d % 360
		}
	}
}

function _d(a) {
	var b = 1;
	var h = qqwj.Event.addEvent;
	return h(document.body, "mousedown", function () {
		b = -b
	}),

	function () {
		var c = 0;
		return function () {
			return c += a * b % 360
		}
	}
}

function _e(a, b, c, d) {
	var h = qqwj.Event.addEvent;
	return h(document.body, "mousedown", function () {
		d = -d
	}),

	function () {
		var e = 0,
			f = +new Date;
		return function () {
			var g = +new Date;
			return g - f > c && (a = b - a, f = g),
				e += a * d % 360
		}
	}
}

function _f(a, b, c, d) {
	i[a] = {
		childs: k[b],
		queueCount: c,
		round: j[d]
	}
}

if (!qqwj.game.Jfcz)
{
	qqwj.game.Jfcz = function(canvas, level) {
		this._canvas = canvas;
		this._level = level || 1;
	};

	qqwj.game.Jfcz.Levels = {

		_levels: {},

		_speedAndDirectionSetting: {
			A1: _a(1.5, 1),
			A2: _a(1.5, -1),
			B1: _a(2.5, 1),
			B2: _a(2.5, -1),
			C1: _b(2.2, 3e3),
			C2: _b(3.5, 2e3),
			D1: _c(2, 2.3, 1200, 1),
			D2: _c(2, 2.3, 1200, -1),
			D3: _c(4, 4.5, 1700, 1),
			D4: _c(4, 4.5, 1700, -1),
			D5: _c(4, 4.5, 1700, 1),
			D6: _c(4, 4.5, 1700, -1),
			E1: _d(2),
			E2: _e(2, 2.3, 1e3, 1)
		},

		_angleSetting: {
			0: [],
			2: [0, 180],
			3: [0, 120, 240],
			4: [0, 90, 180, 270],
			5: [0, 72, 144, 216, 288],
			6: [0, 60, 120, 180, 240, 300],
			7: [0, 52, 103, 155, 206, 258, 309],
			8: [0, 45, 90, 135, 180, 225, 270, 315],
			9: [0, 40, 80, 120, 160, 200, 240, 280, 320],
			10: [0, 36, 72, 108, 144, 180, 216, 252, 288, 324],
			11: [0, 33, 66, 99, 131, 164, 197, 230, 262, 295, 328],
			12: [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330],
			13: [0, 28, 56, 84, 111, 139, 167, 194, 222, 250, 277, 305, 333],
			14: [0, 26, 52, 78, 103, 129, 155, 180, 206, 232, 258, 283, 309, 335],
			15: [0, 24, 48, 72, 96, 120, 144, 168, 192, 216, 240, 264, 288, 312, 336],
			16: [0, 23, 45, 68, 90, 113, 135, 158, 180, 203, 225, 248, 270, 293, 315, 338]
		},

		_levelsSetting: {
			1: ["4", 8, "A1"],
			2: ["6", 10, "A1"],
			3: ["2", 20, "A1"],
			4: ["8", 12, "A2"],
			5: ["12", 8, "A1"],
			6: ["10", 10, "A2"],
			7: ["12", 13, "A1"],
			8: ["16", 3, "A2"],
			9: ["0", 26, "A2"],
			10: ["16", 10, "A1"],
			11: ["10", 8, "B1"],
			12: ["6", 12, "B2"],
			13: ["12", 4, "B1"],
			14: ["8", 14, "B2"],
			15: ["8", 6, "B1"],
			16: ["5", 10, "B2"],
			17: ["6", 12, "B1"],
			18: ["8", 14, "B2"],
			19: ["0", 23, "B1"],
			20: ["10", 13, "B2"],
			21: ["4", 12, "C1"],
			22: ["6", 10, "C1"],
			23: ["8", 12, "C1"],
			24: ["7", 14, "C1"],
			25: ["2", 18, "C1"],
			26: ["4", 18, "C1"],
			27: ["0", 24, "C1"],
			28: ["4", 10, "C2"],
			29: ["6", 13, "C2"],
			30: ["4", 20, "C1"],
			31: ["6", 8, "D1"],
			32: ["2", 12, "D2"],
			33: ["3", 14, "D2"],
			34: ["3", 18, "D1"],
			35: ["8", 12, "D1"],
			36: ["7", 15, "D2"],
			37: ["16", 8, "D2"],
			38: ["0", 23, "D1"],
			39: ["12", 12, "D1"],
			40: ["12", 15, "D2"],
			41: ["5", 10, "E1"],
			42: ["6", 12, "E1"],
			43: ["3", 15, "E1"],
			44: ["3", 19, "E1"],
			45: ["0", 24, "E1"],
			46: ["2", 15, "E2"],
			47: ["4", 16, "E2"],
			48: ["12", 8, "E2"],
			49: ["3", 20, "E2"],
			50: ["16", 14, "E2"],
			51: ["4", 6, "D3"],
			52: ["4", 12, "D4"],
			53: ["6", 13, "D3"],
			54: ["0", 24, "D4"],
			55: ["4", 21, "D3"],
			56: ["16", 16, "A1"],
			57: ["4", 24, "C1"],
			58: ["4", 26, "D1"],
			59: ["4", 25, "E2"],
			60: ["13", 19, "E2"]
		},

		_initLevels: function() {
			for (var _levelIndex in this._levelsSetting)
			{
				this._levels[_levelIndex] = {
					childs: this._angleSetting[this._levelsSetting[_levelIndex][0]],
					queueCount: this._levelsSetting[_levelIndex][1],
					round: this._speedAndDirectionSetting[this._levelsSetting[_levelIndex][2]]
				};
				this._levels.length = _levelIndex;
			}
		},

		getLevels: function() {
			if (typeof(this._levels.length) == "undefined")
			{
				this._initLevels();
			}

			return this._levels;
		}

	};

	qqwj.game.Jfcz.Ball = function(context2d, radius, text, fontWidth, scale) {
		this._context2d = context2d;
		this._text = text || "";
		this._scale = scale || 1;
		this._radius = (radius || 12);
		this._fontWidth = (fontWidth || 15);
	};

	qqwj.game.Jfcz.Ball.prototype = {

		_context2d: null,
		_text: "",
		_fontWidth: 15,
		_radius: 12,
		_scale: 1,

		_x: 0,
		_y: 0,

		_drawText: function(text) {
			var fontWidth = this._fontWidth * this._scale;

			var du = qqwj.game.DrawUtils;
			var textWidth = du.getTextWidth(this._context2d, 0, 0, this._text, fontWidth);
			du.drawText(this._context2d, this._x - textWidth / 2, this._y + fontWidth / 3, this._text, fontWidth, "#036f9f");
		},
		
		pos: function(x, y) {
			if (!qqwj.Utils.isNullOrUndefined(x) &&
				!qqwj.Utils.isNullOrUndefined(y))
			{
				this._x = x;
				this._y = y;
			}

			return {
				x: this._x,
				y: this._y
			};
		},

		scale: function(value) {
			if (!qqwj.Utils.isNullOrUndefined(value))
			{
				this._scale = value;
			}
			return this._scale;
		},

		rad: function(value) {
			if (!qqwj.Utils.isNullOrUndefined(value))
			{
				this._radius = value;
			}
			return this._radius;
		},

		render: function(showText) {
			var radius = this._radius * this._scale;

			var u = qqwj.Utils;
			var du = qqwj.game.DrawUtils;
			du.drawCircle(this._context2d, this._x, this._y, radius, "#ffffff"),
				!u.isNullOrUndefined(this._text) ? this._drawText(this._text) : 
				!u.isNullOrUndefined(showText) && this._drawText(showText)
		},

		destroy: function() {
		}

	};

	qqwj.game.Jfcz.Tween = {
		isEnd: !0,
		
		simple: function(b, c, d, e) {
			var f = (c - b) / e,
				g = +new Date;
			return e > g - d ? (this.isEnd = !1, b + (g - d) * f) : (this.isEnd = !0, c)
		}
	};

	qqwj.game.Jfcz.Collide = {
		check: function(b, c, d) {
			var u = qqwj.Utils;

			var e = b.childs(),
				f = e.length,
				g = Math.ceil(2 * c.rad());
			for (d = d || 1; f--;)
				if (c !== e[f].ball && u.getPointDistance(c.pos(), e[f].ball.pos()) <= g + Math.ceil(2 * d)) return !0;
			return !1
		}
	};

	qqwj.game.Jfcz.Core = function(canvas, context2d, level, f, g) {
		this._canvas = canvas;
		this._context2d = context2d;

		this._g = g || 1;
		this._n = this._canvas.width / 2;
		this._o = 4 * this._m * this._g;

		this._centreBall = new qqwj.game.Jfcz.Ball(this._context2d, this._m, level, f, g);
		this._centreBall.pos(this._n, this._o);

		this._pos = this._centreBall.pos();
	};

	qqwj.game.Jfcz.Core.prototype = {
		_canvas: null,
		_context2d: null,

		_centreBall: null,

		_g: 0,
		_k: 0,
		_l: [],
		_m: 50,
		_n: 0,
		_o: 0,

		centreBallPos: function(x, y) {
			return this._centreBall.pos(x, y);
		},

		centreBallScale: function(value) {
			return this._centreBall.scale(value);
		},

		centreBallRad: function(value) {
			return this._centreBall.rad(value);
		},

		angle: function(a) {
			return "undefined" != typeof(a) && (this._k = a), this._k;
		},

		addChild: function(a, b) {
			this._l.push({
				angle: a,
				ball: b
			});
		},

		clear: function() {
			this._l = [];
		},

		childs: function() {
			return this._l;
		},

		update: function() {
			for (var a, b, c, d, e = this._l.length; e--;) 
				a = 3 * Math.cos((this._l[e].angle + this.angle()) * Math.PI / 180) * this._m * this._g + this._n,
				b = 3 * Math.sin((this._l[e].angle + this.angle()) * Math.PI / 180) * this._m * this._g + this._o,
				c = a / Math.abs(a),
				d = b / Math.abs(b),
				this._l[e].ball.pos(a, b)
		},

		render: function() {
			var w = this._canvas.width;
			var h = this._canvas.height;
			this._context2d.clearRect(0, 0, w, h);

			var du = qqwj.game.DrawUtils;

			var len = this._l.length;
			for (var c = 0; len > c; c++)
			{
				du.drawLine(this._context2d, this._n, this._o,
					this._l[c].ball.pos().x,
					this._l[c].ball.pos().y,
					"#ffffff", 1.5 * this._g);
				this._l[c].ball.render();
			}

			this._centreBall.render();
		},

		destroy: function() {
			this.clear();
		}
	};

	qqwj.game.Jfcz.UserBallList = function(count, f, g, context2d, j) {
		this._context2d = context2d;

		this._f = f;
		this._g = g;
		this._j = j;
		
		this._init(count);
	};

	qqwj.game.Jfcz.UserBallList.prototype = {

		_context2d: null,

		_ballList: [],
		_popupBallList: [],

		_f: 0,
		_g: 0,
		_j: 0,

		_k: function(count) {
			for (var i = count, result = []; i--;)
			{
				result.push(i + 1);
			}
			return result;
		},

		_init: function(count) {
			var b, d, e = this._k(count),
				j = e.length;
			for (b = 0; j > b; b++)
			{
				d = new qqwj.game.Jfcz.Ball(this._context2d, null, e[b], null, this._j),
				d.pos(this._f, this._g + 2.5 * d.rad() * b),
				this._ballList.push(d);
			}
		},

		add: function() {
		},

		remove: function(a) {
			var b = this._ballList[a];
			return this._ballList.splice(a, 1), b;
		},

		clear: function() {
			this._ballList = [];
			this._popupBallList = [];
		},

		getUnpopupCount: function() {
			return this._ballList.length;
		},

		popup: function() {
			var topBall = this._ballList.shift();
			topBall.st = +new Date;
			topBall.sv = topBall.pos().y;
			this._popupBallList.push(topBall);
		},

		update: function() {
			var a, b, c, h = this._popupBallList.length,
				i = this._ballList.length;
			if (h)
			{
				var t = qqwj.game.Jfcz.Tween;

				for (b = this._popupBallList[0].rad(), a = this._g - 3 * b; h--;)
				{
					this._popupBallList[h].pos(this._f, t.simple(this._popupBallList[h].sv, a, this._popupBallList[h].st, 50));
					c = this._popupBallList[this._popupBallList.length - 1].pos().y,
						this._popupBallList[h].pos().y === a && (qqwj.UserEvent.fire("popup", this._popupBallList[h]), this._popupBallList.splice(h, 1));
				}

				for (; i--;)
				{
					this._ballList[i].pos(this._f, c + 2.5 * b * (i + 1));
				}
			}
		},

		render: function() {
			for (var a = this._ballList.length, b = this._popupBallList.length; a--;)
			{
				this._ballList[a].render();
			}

			for (; b--;)
			{
				this._popupBallList[b].render();
			}
		},

		on: function(event, func) {
			qqwj.UserEvent.add(event, func);
		},

		off: function(event, func) {
			qqwj.UserEvent.remove(event, func);
		},

		destroy: function() {
		}

	};

	qqwj.game.Jfcz.Scene = function(canvas, context2d, j) {
		this._canvas = canvas;
		this._context2d = context2d;

		this._levels = qqwj.game.Jfcz.Levels.getLevels();
		this._j = j;
	};

	qqwj.game.Jfcz.Scene.prototype = {

		_canvas: null,
		_context2d: null,

		_levelSetting: null,
		
		_ball: null,
		_collide: null,
		_levels: null,

		_enabled: !1,
		_curLevel: 1,
		_state: "run",

		_w: null,
		_userBallList: null,
		_j: 0,
		_y: null,
		_v: null,

		_n: function(levelSetting) {
			this._levelSetting = levelSetting;
			
			var g = levelSetting.childs,
				h = g.length;
			var f = qqwj.game.Jfcz.Collide;

			var thisObj = this;

			for (this._y = levelSetting.round(), this._w && this._w.destroy(), 
				this._w = new qqwj.game.Jfcz.Core(this._canvas, this._context2d, this._curLevel, 50, this._j) ; h--;) this._w.addChild(g[h], new qqwj.game.Jfcz.Ball(this._context2d, null, "", null, this._j));

			this._userBallList && this._userBallList.destroy(),
				this._userBallList = new qqwj.game.Jfcz.UserBallList(levelSetting.queueCount, 
				this._canvas.width / 2, this._w.centreBallPos().y + 4 * this._w.centreBallRad(), this._context2d, this._j),
				this._userBallList.on("popup", function (a) {
					thisObj._w.addChild(90 - thisObj._w.angle(), a),
						f.check(thisObj._w, a, thisObj._j) ? (z = a, thisObj._s()) : !thisObj._userBallList.getUnpopupCount() && thisObj._r();
				})
		},

		_s: function() {
			"fail" != this._state && (this._state = "fail", this._v = +new Date);
		},

		_r: function() {
			"pass" != this._state && (this._state = "pass", this._v = +new Date);
		},

		_o: function() {
			this._y && (this._w.angle(this._y()), this._w.update(), this._userBallList.update());
		},

		_p: function() {
			var b, c, d, e, f = this._w.childs(),
				g = f.length,
				h = 25;
			for (; g--;)
			{
				b = f[g].angle + this._w.angle(),
                c = Math.cos(b * Math.PI / 180) * h,
                d = Math.sin(b * Math.PI / 180) * h,
                e = f[g].ball.pos(),
                f[g].ball.pos(e.x + c, e.y + d)			}
		},

		_q: function(a) {
			var b, c = [25, 15, 20, 15],
				d = c.length,
				e = 200,
				f = e / d;
            for (this._w.update(), b = 1; d >= b; b++) a > f * b && z.rad(c[b - 1] * this._j)
		},
		
		getState: function() {
			return this._state;
		},
		
		getShotCount: function() {
			var result = this._levelSetting.queueCount - this._userBallList.getUnpopupCount();
			if (this._state == "fail")
			{
				return Math.max(0, result - 1);
			}
			return result;
		},

		run: function(level) {
			var c = this._levels[level];
			this._curLevel = level;
			c ? (this._enabled = !0, this._n(c), document.body.style.backgroundColor = "#036f9f", this._state = "run") : t();
		},

		shot: function() {
			this._userBallList && this._userBallList.getUnpopupCount() && this._userBallList.popup();
		},

		update: function() {
			var a;
			this._enabled && 
				("run" === this._state ? this._o() : 
				"pass" === this._state ? 
				(this._p(), +new Date - this._v > 1e3 && (this._state = "", qqwj.UserEvent.fire("passed"))) : "fail" === this._state && (a = +new Date - this._v, this._q(a), a > 1e3 && (this._state = "", qqwj.UserEvent.fire("failed"))));
		},

		render: function() {
			this._enabled && (this._w.render(), this._userBallList.render());
		},
		
		end: function(state) {
			this._state = "";

			if (state === "pass")
			{
				qqwj.UserEvent.fire("passed");
			}
			else
			{
				qqwj.UserEvent.fire("failed")
			}
		},

		on: function(event, func) {
			qqwj.UserEvent.add(event, func);
		},

		off: function(event, func) {
			qqwj.UserEvent.remove(event, func);
		}

	};

	qqwj.game.Jfcz.Switcher = function(c2d, w, h) {
		this._context2d = c2d;
		this._canvasWidth = w;
		this._canvasHeight = h;
	};

	qqwj.game.Jfcz.Switcher.prototype = {
		_context2d: null,
		_canvasWidth: 0,
		_canvasHeight: 0,

		_point: [0, 0],
		_enabled: !1,
		_color: "#c8c8c8",

		_g: !1,
		_d: null,
		_e: null,
		_f: null,

		update: function() {
			var a = this._point;
			var c = 30;
			this._enabled && (0 === this._e ? (this._d = this._color, a[0] < this._canvasWidth / 2 ? (a[0] = Math.min(a[0] + this._canvasHeight, this._canvasWidth / 2), this._point = a) : (this._point = a, this._g = !0)) : 1 === this._e && (this._d = "#000", a[0] > this._canvasWidth / 2 ? (a[0] = Math.max(a[0] - this._canvasHeight, this._canvasWidth / 2), this._point = a) : (this._point = a, this._g = !0)));
		},

		render: function() {
			var e = this._point;
			this._enabled && (this._context2d.fillStyle = this._d, 
				this._context2d.fillRect(e[0] - this._canvasWidth - 2, e[1] - this._canvasHeight / 2, this._canvasWidth, this._canvasHeight), 
				this._g && (this._enabled = !1, this._f && this._f()));
		},

		switchStage: function(d, i) {
			0 === d ? 
				this._point = [-this._canvasWidth / 2, this._canvasHeight / 2] : 1 === d && (this._context2d.fillStyle = this._color, this._context2d.fillRect(0, 0, this._canvasWidth, this._canvasHeight), this._point = [this._canvasWidth + this._canvasWidth / 2, this._canvasHeight / 2]),
				this._enabled = !0,
				this._g = !1,
				this._e = d,
				this._f = i
		}

	};

	qqwj.game.Jfcz.prototype = {

		_canvas: null,
		_context2d: null,

		_runTimeId: 0,

		_level: 1,

		_switcher: null,
		_scene: null,

		init: function() {
			this._canvas.width = (document.body.clientWidth || 
				document.documentElement.clientWidth);
			this._canvas.height = (document.body.clientHeight || 
				document.documentElement.clientHeight) - 5;

			this._context2d = this._canvas.getContext("2d");

			var x2 = document.body.offsetHeight;
/*
			var x2 = 609;
			if (!qqwj.Utils.isMobile && !qqwj.Utils.isWeixin) {
				x2 = 700;
			}
*/
			this._switcher = new qqwj.game.Jfcz.Switcher(
				this._context2d, this._canvas.width, this._canvas.height);
			this._scene = new qqwj.game.Jfcz.Scene(this._canvas, 
				this._context2d, this._canvas.height / x2);

			var thisObj = this;
			var n = qqwj.Event.addEvent;
			n(document.body, "mousedown", function (a) {
				if (thisObj._scene.getState() != "run")
				{
					return;
				}
				
                var b;
                if (a && a.changedTouches)
                    for (b = a.changedTouches.length; b--;) 
						thisObj._scene.shot();
                else 
					thisObj._scene.shot();
                "1" != a.target.getAttribute("data-capture") && qqwj.Event.stopEvent(a)
            });

//			this._scene.on("passed", function() {
//				document.body.style.backgroundColor = "#a7ca25";
//				document.getElementById("stage").style.background = "#a7ca25";
//			});
//
//			this._scene.on("failed", function() {
//				document.body.style.backgroundColor = "#ff3745";
//				document.getElementById("stage").style.background = "#ff3745";
//			});
		},

		getCanvas: function() {
			return this._canvas;
		},

		getContext: function() {
			return this._context2d;
		},

		getLevel: function() {
			return this._level;
		},
		
		getState: function() {
			return this._scene.getState();
		},

		_run: function() {
			window.clearTimeout(this._runTimeId);

			this._scene.update();
			this._scene.render();
			this._switcher.update();
			this._switcher.render();

			var thisObj = this;
			this._runTimeId = window.setTimeout(function() {
				thisObj._run();
			}, 1e3 / 60);
		},

		ready: function() {
			this._run();
		},

		c: {},

		d: undefined,

		start: function(b) {
			"use strict"
			var e, f, g;
			if (b = b.toLowerCase(), this.d = this.c[b], this.d && this.d.length)
			{
				for (e = Array.prototype.slice.call(arguments, 1), g = this.d.length, f = 0; g > f; f++)
				{
					this.d[f].apply(a, e);
				}
			}

			var thisObj = this;
			this._switcher.switchStage(1, function() {
				thisObj._scene.run(thisObj._level);
			});
		},
		
		getShotCount: function() {
			return this._scene.getShotCount();
		},
		
		end: function(state) {
			this._scene.end(state);
		},

		on: function(event, func) {
			this._scene.on(event, func);
		},

		off: function(event, func) {
			this._scene.off(event, func);
		},

		destroy: function() {
			window.clearTimeout(this._runTimeId);
		}

	};
}