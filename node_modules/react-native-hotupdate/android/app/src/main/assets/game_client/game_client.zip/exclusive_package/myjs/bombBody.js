﻿/*
实体类
*/
mddBll.bombItemsBean = function (pItem) {
    this.id = pItem["id"];//编号
    this.redpacketId = pItem["redpacketId"];//红包编号
    this.sequence = pItem["sequence"];//序列
    this.amount = pItem["amount"];//分配的金额
    this.time = pItem["time"];//时间毫秒
    this.owner = pItem["owner"];//所有者的id
    this.ownerName = pItem["ownerName"];//所有者的名字
    this.ownerPicUrl = pItem["ownerPicUrl"];//所有者头像
    this.ownerSex = pItem["ownerSex"];//所有人性别
    this.status = pItem["status"];//状态(0->没抢/1->抢)
    this.kind = pItem["kind"];//种类
    this.isAutoGrab = pItem["isAutoGrab"];//是否自动抢
    this.qqi = pItem["qqi"];//亲亲指数
    return this;
};
mddBll.bombredpacketBean = function (pRedpacket) {
    this.id = pRedpacket["id"];//编号
    this.amount = pRedpacket["amount"];//获取金额
    this.count = pRedpacket["count"];//数量
    this.grabCount = pRedpacket["grabCount"];//已获取的份数
    this.version = pRedpacket["version"];//版本
    this.summary = pRedpacket["summary"];//显示文本
    this.time = pRedpacket["time"];//时间
    this.owner = pRedpacket["owner"];//所有者id
    this.ownerName = pRedpacket["ownerName"];//所有者姓名
    this.ownerPicUrl = pRedpacket["ownerPicUrl"];//所有者的图片
    this.sceneType = pRedpacket["sceneType"];//场景类型
    this.sceneKey = pRedpacket["sceneKey"];//场景key
    this.type = pRedpacket["type"];//类型
    this.status = pRedpacket["status"];//状态(1->没抢完,2->都抢完,3->被回收，时间到了没抢完)
    this.items = new Array();//列表
    for (var i = 0; i < pRedpacket["items"].length; i++) {
        var tIteam = pRedpacket["items"][i];
        this.items.push(new mddBll.bombItemsBean(tIteam));
    }
    return this;
};
//定义实体类
mddBll.bombBean = function (pObj) {
    //成员变量
    this.grabamount = pObj["grabamount"];//当前获取人的金额
    this.isGet = pObj["isGet"];//是否抢过当前红包
    this.isGrab = pObj["isGrab"];//当前红包是否被当前以外人抢过
    this.redpacket = new mddBll.bombredpacketBean(pObj["redpacket"]);//红包内容
    this.serverTime = pObj["serverTime"];//服务器时间
    return this;
};
//红包状态
mddBll.walletbalance = function (pObj) {
    //成员变量
    this.balance = pObj["balance"];
    this.WithDrawRule = pObj["WithDrawRule"];
    this.qqi = pObj["qqi"];
    this.QqiRule = pObj["QqiRule"];
    return this;
}