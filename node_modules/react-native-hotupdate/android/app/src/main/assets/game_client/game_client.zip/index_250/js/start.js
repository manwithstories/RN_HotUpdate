    /*
    状态页面
    */
    var tPackage_id=0;//全局packageid
    //设置启动页面
function doSetInitPage(pPageId, InitCallBack) {
    //所有page
    var pageArray = getPageArray();
    for (var i = 0; i < pageArray.length; i++) {
        jQuery("div" + pageArray[i]).removeClass("ui-page-active");
    }
    jQuery("div" + pPageId).addClass("ui-page-active");
    // doTestDebUi("doSetInitPage"+pPageId+",step6");
    InitCallBack(pPageId);
}//end doSetInitPage
function getPageArray()
{
    return  ["#pageindex", "#pageSelect"];
}//end getPageArray
function getActivetyPage()
{
    return jQuery("div.ui-page-active").attr("id");
}//end getActivetyPage
// function doJumpToStatus(pPackageId,pJwt)
// {
//  var tBaseURiParam=window.location.search;
//  var tLink =jQuery.changeURLPar("/index.html"+tBaseURiParam,"package_id",pPackageId);
//  tLink= jQuery.getMddRootPath()+"/index_250"+tLink;
//  doMddReOpenCleint(tLink);
//  //启动页面
//  // tLink= jQuery.changeURLPar(tLink,"Authorization",pJwt);
//  // tLink= jQuery.changeURLPar(tLink,"initpage","#pageSelect");
//  //myUIAlert("tLink:"+tLink);
//  // window.location.href=tLink;

//             //"./index.html?package_id="+tPackage_id;
// }
function doRefreshUi()
{
var padding=0;
var screen_with=$(".TopNavLine").width();//$(window).width();
var screen_height=$(window).height();
var CenterLenth=screen_with-2*padding;
var padding=20;
var baseWidth=509;
var baseHeight=509;
var baseCenterButonW=214;
var baseCenterButonTop=150;
var baseCenterButonLeft=140;
var baseCenterButonImgLeft=-107;
$(".topBigDiv").css("width","100%");
$(".ly-plate").css("width",CenterLenth+"px");
$(".ly-plate").css("height",CenterLenth+"px");
$(".rotate-bg").css("width",CenterLenth+"px");
$(".rotate-bg").css("height",CenterLenth+"px");
$(".lottery-star").css("width",(CenterLenth*baseCenterButonW/baseWidth)+"px");
$(".lottery-star").css("height",(CenterLenth*baseCenterButonW/baseWidth)+"px");
$(".lottery-star").css("top",(CenterLenth*baseCenterButonTop/baseWidth)+"px");
$(".lottery-star").css("left",(CenterLenth*baseCenterButonLeft/baseWidth)+"px");
// $("#lotteryBtn").css("left",(CenterLenth*baseCenterButonImgLeft/baseWidth)+"px");
}
function create(callback)
{
    var create_package_url = "/game_server/index_250/create_package/";
    doServerOperWithJWT_PC(create_package_url, {"csrfmiddlewaretoken":  getCookie('csrftoken')}, function (data) {
        //jQuery("#create_game").removeAttr("disabled");
        try {
            var resCode = data["ok"];
            if (resCode == true) {
                callback(data);
            }
            else {
                var tErr=data["error"];
                if(tErr=="package_still_running")
                {
                    myUIAlert("您还有未过期的炸弹!");
                }else{
                    myUIAlert("创建失败!");
                }
                console.log(data);
            }
        } catch (e) {
            myUIAlert(JSON.stringify(e));
        }

    }, function (textStatus) {
        myClientLog(textStatus);
    }, function (error) {
        myUIAlert(JSON.stringify(error));
    });
}
function doGetQqi(callback) {
        var get_user_qqi_url = "/game_server/get_user_qqi/";
        doServerGetOperWithJWT_PC(get_user_qqi_url, {}, function (data) {
            try{
                var resCode = data["ok"];
                if (resCode == true) {
                    var userMoney = parseInt(data["balance"]);
                    callback(userMoney);
                }
                else {
                    console.log(data);
                }
            }
            catch(e)
            {
                myClientLog("doGetQqi异常:"+JSON.stringify(e));
            }

        }, function (textStatus) {
            myClientLog(textStatus);
        }, function (error) {
            myClientLog(error);
        });
    }
function doInitIndex()
{
     // jQuery("#create_game").attr("disabled","disabled");
            doGetQqi(function(index_balance){
                $("#my_index").html("" + index_balance);
                if (index_balance< 50) {
                    myUIAlert("账户指数不足50，去打赏亲友的讨红包吧。");
                }else{
                    jQuery("#create_game").removeAttr("disabled");
                }
            });
            $("#create_game").click(function() {
                doGetQqi(function(index_balance){
                    if (index_balance < 50) {
                        myUIAlert("账户指数不足50，去打赏亲友的讨红包吧。");
                    } else {
                        //跳转到状态页面
                        // doJumpToStatus();
                        // jQuery("#create_game").attr("disabled","disabled");
                        // //缓存jwt
                        // var tjwt=getJWt();
                        // if(tjwt!="")
                        // {
                        //     jQuery(".hid_jwt").val(tjwt);
                        // }
                        //alert("jwt:"+jQuery("#hid_jwt").val());
                        create(function callback(data){
                            tPackage_id=data["package"]["id"];
                            // doJumpToStatus(tPackage_id,tjwt);
                                        //转到另一个子页面
                            doSetInitPage("#pageSelect", function InitCallBack(pPageId) {
                                doInitSelectPage();
                            });
                        });
                        //doJumpToStatus();
                    }
                });
            });

     var ListenterChange = function () {
        //页面加载先来一下
                doRefreshUi();
        //控制logo的显示位置 Begin

        if (typeof document.addEventListener != "undefined") {
            //document.addEventListener("mousedown", _lhlclick, true);
            window.addEventListener("resize", function () {
                // 得到屏幕尺寸 (内部/外部宽度，内部/外部高度)
                        doRefreshUi();
            }, false);
        } else {
            //document.attachEvent("onmousedown", _lhlclick);
            window.attachEvent("resize", function () {
                // 得到屏幕尺寸 (内部/外部宽度，内部/外部高度)
                        doRefreshUi();
            }, false);
        }

    }
                //改变
        ListenterChange();
}//end doInitIndex
    /*选择模块 用户位置*/
     //选取250
    function doPick250(statecallback) {
        var tUrl = mddBll.bll250.kURLPick_250.format({ "package_id": tPackage_id });
        doServerOperWithJWT_PC(tUrl, { "step": userPlace, "csrfmiddlewaretoken": getCookie('csrftoken') }, function (data) {
            try{
                    if (data != undefined) {
                    var resCode = data["ok"];
                    if (resCode == true) {
                        var tStatusBean = new mddBll.bll250.bll250BigSuc(data);
                        statecallback(tStatusBean);
                    }
                    else {
                        var tStatusBean = new mddBll.bll250.bll250BigErr(data);
                        statecallback(tStatusBean);
                    }
                }else{
                    myUIAlert("选择失败");
                }
            }catch(e)
            {
                myClientLog("doPick250请求异常:"+JSON.stringify(e));
            }

        }, function (textStatus) {
            myClientLog(textStatus);
        }, function (error) {
            myClientLog(error);
        });
    }//end doPick250
    var userPlace = 0;
    function doJumpToStart() {
        if(userPlace==0)
        {
            debugger;
            myUIAlert("自动随机选择数字!");
            randValue(function callback(){
                        jQuery("#btn_start_pick").attr("disabled","disabled");
                    try{
                        myClientLog("userPlace:"+userPlace);
                        doPick250(function statecallback(pStatusBean) {
                        if (pStatusBean.ok == true) {
                            myUIAlert("选择成功!");
                            doJumpToStatus();
                        } else {
                            if (pStatusBean.error == mddBll.bll250_state.kState_has_picked) {
                                myUIAlert("已经选过数了，等着开奖");
                                doJumpToStatus();
                            } else if (pStatusBean.error == mddBll.bll250_state.kState_timeout) {
                                myUIAlert("超时,已经选过数了");
                                doJumpToStatus();
                            } else if (pStatusBean.error == mddBll.bll250_state.kState_not_join) {
                                myUIAlert("未加入");
                                doMddCloseClient();
                            } else {
                                myUIAlert("未知情况");
                                doMddCloseClient();
                            }
                        }
                        });
                    }catch(e)
                    {
                        myClientLog("选择错误:"+JSON.stringify(e));
                    }
            });
        }else{
            jQuery("#btn_start_pick").attr("disabled","disabled");
            try{
                doPick250(function statecallback(pStatusBean) {
                if (pStatusBean.ok == true) {
                    myUIAlert("选择成功!");
                    doJumpToStatus();
                } else {
                    if (pStatusBean.error == mddBll.bll250_state.kState_has_picked) {
                        myUIAlert("已经选过数了，等着开奖");
                        doJumpToStatus();
                    } else if (pStatusBean.error == mddBll.bll250_state.kState_timeout) {
                        myUIAlert("超时,已经选过数了");
                        doJumpToStatus();
                    } else if (pStatusBean.error == mddBll.bll250_state.kState_not_join) {
                        myUIAlert("未加入");
                        doMddCloseClient();
                    } else {
                        myUIAlert("未知情况");
                        doMddCloseClient();
                    }
                }
                });
            }catch(e)
            {
                myClientLog("选择错误:"+JSON.stringify(e));
            }
        }


    }//end doJumpToStart
    function doJumpToStatus() {
       doMddCloseClient();
    }//end doJumpToStatus
    function doSelectPosRand(pDom) {
        var maxlength = 5;
        userPlace = Math.floor(Math.random() * maxlength+1);
        if(userPlace>5)
            userPlace=5;
        //alert(userPlace);
        doChangeStyle(pDom);
    }//end doSelectPosRand
    function randValue(callback)
    {
        var maxlength = 5;
        userPlace = Math.floor(Math.random() * maxlength+1);//1~5
        if(userPlace>5)
            userPlace=5;
        var tSelectObj=undefined;
        jQuery("a.SixButtonNum").each(function(){
           if($(this).html()==(userPlace+""))
           {
                tSelectObj=$(this);
           }
        });
        if(typeof(tSelectObj)!="undefined")
        {
            tSelectObj.click();
        }
        callback();
    }//end randValue
    function doSelectPos(pDom) {
        userPlace = jQuery(pDom).text();
        //alert(userPlace);
        doChangeStyle(pDom);
    }//end doSelectPos
    function doChangeStyle(pDom) {
        //SixButtonRandA
        var parDiv = jQuery(pDom).parent();
        //清空
        jQuery(".SixButtonRandA").removeClass("SixButtonRandA");
        parDiv.addClass("SixButtonRandA");
        jQuery("#btn_start_pick").removeAttr("disabled");
    }//end doChangeStyle
function doInitSelectPage() {
    jQuery("#btn_start_pick").attr("disabled","disabled");
    doGetQqi(function (index_balance) {
        $("#lbl_qqzs").html("当前我的亲亲指数：" + index_balance);
        if (index_balance < 50) {
            myUIAlert("账户指数不足50，去打赏亲友的讨红包吧。");
        }else{
            jQuery("#btn_start_pick").removeAttr("disabled");
        }
    });
}//end doInitSelectPage
$(document).ready(function () {
    doSetInitPage("#pageindex", function InitCallBack(pPageId) {
             doInitIndex();
            //开始页面
            // if (pPageId == "#pageindex") {
            //     doInitIndex();
            // }
            //     //选择页面
            // else if (pPageId == "#pageSelect") {
            //     // debugger;
            //     // jQuery("#pageindex").removeClass("ui-page-active");
            // }
        });
});