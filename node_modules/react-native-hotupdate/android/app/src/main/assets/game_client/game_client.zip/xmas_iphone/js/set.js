//var messa = document.querySelector("#message");
//messa.innerHTML = "docu"+document.documentElement.offsetWidth+",window"+window.innerWidth;
document.getElementsByTagName("html")[0].style.fontSize = window.innerWidth / 20 + "px";
var imgSrcArr = ["img/Ashui1.png", "img/Ashui2.png", "img/Ashui3.png", "", "img/Ashui4.png"];
var bottleSrcArr = ["img/QIshd1.png", "img/QIshd2.png", "img/QIshd3.png", "img/QIshd4.png", "img/QIshd5.png"];
var containerSnow = document.getElementById("container_snow");
containerSnow.style.width = "20rem";
containerSnow.style.height = "35.8rem";
document.querySelector("body").style.height = document.querySelector(".container").offsetHeight + "px";
var imgs = imgSrcArr.concat(bottleSrcArr);
var nu = 0;
window.onresize = function(){
	setScreen();
}
window.onload = function(){
	setScreen();
}
function setScreen(){
	document.getElementsByTagName("html")[0].style.fontSize = window.innerWidth / 20 + "px";
	var canvasArr = document.querySelectorAll("canvas");
	for(var i = 0 ; i < canvasArr.length ; i ++){
		canvasArr[i].style.width = containerSnow.offsetWidth + "px";
	}
	document.querySelector("body").style.height = document.querySelector(".container").offsetHeight + "px";
}
var water1 = document.querySelector(".waterCellNum1");
var water2 = document.querySelector(".waterCellNum2");
var water3 = document.querySelector(".waterCellNum3");
var water4 = document.querySelector(".waterCellNum4");
var water5 = document.querySelector(".waterCellNum5");
var rankCells = document.querySelector(".rankCells");
var myscoreDiv = document.querySelector("#myscore");
var mycountDiv = document.querySelector("#mycount");
var mylevelDiv = document.querySelector("#mylevel");
var gameScorePortDiv = document.querySelector(".gameScorePort");
var gameScoreSpan = document.querySelector(".gameScorePort span");

function tip3(){
	document.querySelector(".gameScorePort").className = "gameScorePort appearport";
	setTimeout(function(){
		document.querySelector(".gameScorePort").style.display = "none";
	},250);
}
var container = document.querySelector(".container");
var watering = false;
var bottole = document.querySelector(".waterNow");
bottole.num = 1;
var water = document.querySelector(".water");
var waterTip = document.querySelector(".watertip");
waterTip.pay = 1;
var payNum = document.querySelector(".payNum");
var waterexit = document.querySelector(".watertip_control_exit");
var waterPayed = document.querySelector(".watertip_control_pay");
function tip1(){
	waterTip.className = "watertip appearport";
	setTimeout(function(){
		waterTip.style.display = "none";
		waterTip.className = "watertip";
	},250);
}
function tip2(){
	commitBag(waterTip.pay);
	waterTip.className = "watertip appearport";
	setTimeout(function(){
		waterTip.style.display = "none";
		waterTip.className = "watertip";
	},250);
}


water1.addEventListener("touchstart", function() {
	waterTip.style.display = "block";
	waterTip.className = "watertip  occport";
	waterTip.style.zIndex = 999999;
	payNum.innerHTML = "本次浇水将使用1个亲亲指数，或1分红包，是否希望如此？";
	waterTip.pay = 1;
	bottole.style.backgroundImage = "url(" + bottleSrcArr[(waterTip.pay-1)] + ")";
//	waterAct1();
}, false);
water2.addEventListener("touchstart", function() {
	waterTip.style.display = "block";
	waterTip.className = "watertip  occport";
	waterTip.style.zIndex = 999999;
	payNum.innerHTML = "本次浇水将使用10个亲亲指数，或10分红包，是否希望如此？";
	waterTip.pay = 2;
	bottole.style.backgroundImage = "url(" + bottleSrcArr[(waterTip.pay-1)] + ")";
//	waterAct2();
}, false);
water3.addEventListener("touchstart", function() {
	waterTip.style.display = "block";
	waterTip.className = "watertip occport";
	waterTip.style.zIndex = 999999;
	payNum.innerHTML = "本次浇水将使用20个亲亲指数，或20分红包，是否希望如此？";
	waterTip.pay = 3;
	bottole.style.backgroundImage = "url(" + bottleSrcArr[(waterTip.pay-1)] + ")";
//	waterAct3();
}, false);
water4.addEventListener("touchstart", function() {
	waterTip.style.display = "block";
	waterTip.className = "watertip occport";
	waterTip.style.zIndex = 999999;
	payNum.innerHTML = "本次浇水将使用50个亲亲指数，或50分红包，是否希望如此？";
	waterTip.pay = 4;
	bottole.style.backgroundImage = "url(" + bottleSrcArr[(waterTip.pay-1)] + ")";
//	waterAct4();
}, false);
water5.addEventListener("touchstart", function() {
	waterTip.style.display = "block";
	waterTip.className = "watertip occport";
	waterTip.style.zIndex = 999999;
	payNum.innerHTML = "本次浇水将使用100个亲亲指数，或100分红包，是否希望如此？";
	waterTip.pay = 5;
	bottole.style.backgroundImage = "url(" + bottleSrcArr[(waterTip.pay-1)] + ")";
//	waterAct5();
}, false)
var gameScorePort = document.querySelector(".gameScorePort");
gameScorePort.addEventListener("touchstart", function() {
	gameScorePort.className = "gameScorePort appearport";
	gameScorePort.onanimationend = function(){
		gameScorePort.style.display = "none";
		gameScorePort.className = "gameScorePort";
	}
}, false);

function commitBag(index){
	switch(index) {
		case 1:
			waterAct1();
			break;
		case 2:
			waterAct2();
			break;
		case 3:
			waterAct3();
			break;
		case 4:
			waterAct4();
			break;
		case 5:
			waterAct5();
			break;
		default:
			break;
	}
}


bottole.addEventListener("touchstart", function() {
//	commitBag(bottole.num);
	waterTip.style.display = "block";
	waterTip.className = "watertip occport";
}, false);



var timeDis = (new Date("Dec 31,2016 23:59:59").getTime() - new Date().getTime())/1000;
if (timeDis < 0) {
    timeDis = 0;
}
var rankTitle = document.querySelector(".rankTitle");
	var day = parseInt(timeDis/3600/24);
	var hour = parseInt(timeDis%(24*3600)/3600);
	var min = parseInt(timeDis%(24*3600)%3600/60);
	rankTitle.innerHTML = "距开奖还有"+day+"天"+hour+"时"+min+"分";
if (timeDis > 0) {
    var timeTimer = setInterval(function(){
            timeDis -= 60;
            var day = parseInt(timeDis/3600/24);
            var hour = parseInt(timeDis%(24*3600)/3600);
            var min = parseInt(timeDis%(24*3600)%3600/60);
            rankTitle.innerHTML = "距开奖还有"+day+"天"+hour+"时"+min+"分";
            if(timeDis <= 0){
                    clearInterval(timeTimer);
            }
    },60000);
}




function loadXMLDoc(method, url, callback, dataSub) {
	var xmlhttp = new XMLHttpRequest();
	var detail = "";
	var arr = [];
	for(var key in dataSub) {
		var row = key + "=" + dataSub[key];
		arr.push(row);
	}
	detail = arr.join("&");
	xmlhttp.onreadystatechange = function() {
		if(xmlhttp.readyState == XMLHttpRequest.DONE) {
			if(xmlhttp.status == 200) {
				callback(xmlhttp.responseText);
			} else if(xmlhttp.status == 400) {
				occMessage('There was an error 400');
			} else {
				occMessage('something else other than 200 was returned');
			}
		}
	};
	if(method == "GET") {
		if(detail.length > 0) {
			url = url + "?" + detail;
			detail = null;
		}
		xmlhttp.open("GET", baseURL()+url, true);
	} else if(method == "POST") {
		xmlhttp.open("POST",baseURL()+url, true);
	}

	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	if(window.IAObj) {
		xmlhttp.setRequestHeader("Authorization", window.IAObj.getJwt());
	} else {
		xmlhttp.setRequestHeader("Authorization", "Bearer " + getParam('Authorization'));
	}
	xmlhttp.send(detail);
}
function baseURL(){
	if(window.IAObj){
		return window.IAObj.getBaseUrl();
	}else {
		return "http://test.engdd.com";
	}
}


function getParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

function exit() {
	//dir:0发起者，1接受者
	//通讯命令:0开始
	if(checkClient()) {
		var IAMsg = {
			cmd: "24"
		};
		var tJSon = JSON.stringify(IAMsg);
		//jsonz字符串
		IAObj.jsSendCmdJsonStr(tJSon);
	} else {
		alert("未定义客户端桥");
	}
}

function checkClient() {
	var rClient = false;
	if(typeof(IAObj) != "undefined") {
		rClient = true;
	} else {
		rClient = false;
	}
	return rClient;
}

function occMessage(str) {
	var message = document.querySelector(".message");
	message.opacity = 0;
	message.innerHTML = str;
	setTimeout(function() {
		message.style.display = "block";
	}, false)
	message.speed = 0.05;
	message.timer = requestAnimationFrame(render_message);

	function render_message() {
		if(message.opacity <= 1 && message.speed >= 0) {
			message.opacity += message.speed;
			message.style.opacity = message.opacity;
			message.timer = requestAnimationFrame(render_message);
		} else {
			setTimeout(function() {
				message.style.display = "none";
				message.style.opacity = 0;
			}, 200)
		}
	}
}
var exitb = document.querySelector(".exit");
exitb.addEventListener("touchstart", function() {
	exit();
}, false);
var message = document.querySelector(".message");
message.style.left = (window.innerWidth - 250) / 2 + "px";

loadXMLDoc("GET", '/game_server/xmas_iphone/top10/', function(data) {
	var result = JSON.parse(data);
	var rankarr = result.top10;
	var str = "";
	if(result.ok == true) {
		for(var i = 0; i < rankarr.length; i++) {
			var strCell = '<div class="rankCell"><span>' + (i + 1) + '</span><span style="background-image:url(' + rankarr[i]["avatar"] + ')"></span><span>' + rankarr[i]["user_name"] + '</span><span>' + rankarr[i]["times"] + '</span><span>' + rankarr[i]["score"] + '</span></div>';
			str += strCell;
		}
		document.querySelector(".rankCells").innerHTML = str;
		document.querySelector("#myscore").innerHTML = result.myscore;
		document.querySelector("#mycount").innerHTML = result.mytimes;
		if(typeof result.myrank != "number") {
			result.myrank = 0;
		}
		document.querySelector("#mylevel").innerHTML = result.myrank;
	} else {
		occMessage(result.msg);
	}
}, {})

function submitControl(index) {
	loadXMLDoc("POST", '/game_server/xmas_iphone/water/', function(data) {
		var result = JSON.parse(data);
		var rankarr = result.top10;
		var str = "";
		if(result.ok == true) {
			for(var i = 0; i < rankarr.length; i++) {
				var strCell = '<div class="rankCell"><span>' + (i + 1) + '</span><span style="background-image:url(' + rankarr[i]["avatar"] + ')"></span><span>' + rankarr[i]["user_name"] + '</span><span>' + rankarr[i]["times"] + '</span><span>' + rankarr[i]["score"] + '</span></div>';
				str += strCell;
			}
			rankCells.innerHTML = str;
			myscoreDiv.innerHTML = result.myscore;
			mycountDiv.innerHTML = result.mytimes;
			mylevelDiv.innerHTML = result.myrank;
			gameScorePortDiv.style.display = "block";
			gameScorePortDiv.className = "gameScorePort occport";
			setTimeout(function(){
				gameScorePortDiv.className = "gameScorePort";
			},250);
			gameScoreSpan.innerHTML = result.myscore_this_time;
		} else{
			
			if(result.error == "too_late"){
				toolate();
			}else {
				occMessage(result.msg);
			}
		}
	}, {
		"position": index
	})
}

function waterAct1() {
	if(watering == false) {
		var i = 0;
		watering = true;
		water.style.display = "block";
		bottole.style.backgroundImage = "url(" + bottleSrcArr[0] + ")";
		bottole.style.webkitTransform = "rotateZ(30deg)";
		bottole.style.transform = "rotateZ(30deg)";
		bottole.num = 1;
		water.timer = setInterval(function() {
			water.style.backgroundImage = "url(" + imgSrcArr[i] + ")";
			i++;
			if(i >= 1) {
				clearInterval(water.timer);
				water.timer = null;
				setTimeout(function() {
					water.style.display = "none";
					water.style.backgroundImage = "";
					watering = false;
					bottole.style.webkitTransform = "rotateZ(0deg)";
					bottole.style.transform = "rotateZ(0deg)";

					submitControl(1);

				}, 500);
			}
		}, 500);
	}
}

function waterAct2() {
	if(watering == false) {
		var i = 0;
		watering = true;
		water.style.display = "block";
		bottole.style.backgroundImage = "url(" + bottleSrcArr[1] + ")";
		bottole.style.webkitTransform = "rotateZ(30deg)";
		bottole.style.transform = "rotateZ(30deg)";
		bottole.num = 2;
		water.timer = setInterval(function() {
			water.style.backgroundImage = "url(" + imgSrcArr[i] + ")";
			i++;
			if(i >= 2) {
				clearInterval(water.timer);
				water.timer = null;
				setTimeout(function() {
					water.style.display = "none";
					water.style.backgroundImage = "";
					watering = false;
					bottole.style.webkitTransform = "rotateZ(0deg)";
					bottole.style.transform = "rotateZ(0deg)";

					submitControl(2);
				}, 500);
			}
		}, 500);
	}
}

function waterAct3() {
	if(watering == false) {
		var i = 0;
		watering = true;
		water.style.display = "block";
		bottole.style.backgroundImage = "url(" + bottleSrcArr[2] + ")";
		bottole.style.webkitTransform = "rotateZ(30deg)";
		bottole.style.transform = "rotateZ(30deg)";
		bottole.num = 3;
		water.timer = setInterval(function() {
			water.style.backgroundImage = "url(" + imgSrcArr[i] + ")";
			i++;
			i++;
			if(i >= 3) {
				clearInterval(water.timer);
				water.timer = null;
				setTimeout(function() {
					water.style.display = "none";
					water.style.backgroundImage = "";
					watering = false;
					bottole.style.webkitTransform = "rotateZ(0deg)";
					bottole.style.transform = "rotateZ(0deg)";

					submitControl(3);
				}, 500);
			}
		}, 500);
	}
}

function waterAct4() {
	if(watering == false) {
		var i = 0;
		watering = true;
		water.style.display = "block";
		bottole.style.backgroundImage = "url(" + bottleSrcArr[3] + ")";
		bottole.style.webkitTransform = "rotateZ(30deg)";
		bottole.style.transform = "rotateZ(30deg)";
		bottole.num = 4;
		water.timer = setInterval(function() {
			water.style.backgroundImage = "url(" + imgSrcArr[i] + ")";
			i++;
			i++;
			if(i >= 5) {
				clearInterval(water.timer);
				water.timer = null;
				setTimeout(function() {
					water.style.display = "none";
					water.style.backgroundImage = "";
					watering = false;
					bottole.style.webkitTransform = "rotateZ(0deg)";
					bottole.style.transform = "rotateZ(0deg)";

					submitControl(4);
				}, 500);
			}
		}, 400);
	}
}

function waterAct5() {
	if(watering == false) {
		var i = 0;
		var count = 0;
		watering = true;
		water.style.display = "block";
		bottole.style.backgroundImage = "url(" + bottleSrcArr[4] + ")";
		bottole.style.webkitTransform = "rotateZ(30deg)";
		bottole.style.transform = "rotateZ(30deg)";
		bottole.num = 5;
		water.timer = setInterval(function() {
			water.style.backgroundImage = "url(" + imgSrcArr[i] + ")";
			i++;
			i++;
			if(i >= 5 && count == 1) {
				clearInterval(water.timer);
				water.timer = null;
				setTimeout(function() {
					water.style.display = "none";
					water.style.backgroundImage = "";
					watering = false;
					bottole.style.webkitTransform = "rotateZ(0deg)";
					bottole.style.transform = "rotateZ(0deg)";

					submitControl(5);
				}, 500);
			} else if(i >= 5 && count == 0) {
				i = 0;
				count++;
			}
		}, 300);
	}
}
var music = document.querySelector("audio");
var musicImg = document.querySelector(".music");
music.status = 1;
musicImg.addEventListener("touchstart",function(){
	if(music.status == 1){
		music.pause();
		musicImg.style.backgroundImage = "url(img/QIyyg.png)";
		music.status = 0;
	}else {
		music.play();
		musicImg.style.backgroundImage = "url(img/QIyyk.png)";
		music.status = 1;
	}
},false);
function toolate(){
	var newYear = document.querySelector(".happyNewYear");
	newYear.className = "happyNewYear occport";
	newYear.style.display = "block";
}
function canceltoolast(){
	var newYear = document.querySelector(".happyNewYear");
	newYear.className = "happyNewYear appearport";
	setTimeout(function(){
		newYear.style.display = "none";
	},250)
}
