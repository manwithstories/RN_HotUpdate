﻿/*
实体类
*/
mddBll.bombItemsBean = function (pItem) {
    this.id = pItem["id"];//编号
    this.redpacketId = pItem["redpacketId"];//红包编号
    this.sequence = pItem["sequence"];//序列
    this.amount = pItem["amount"];//分配的金额
    this.time = pItem["time"];//时间毫秒
    this.owner = pItem["owner"];//所有者的id
    this.ownerName = pItem["ownerName"];//所有者的名字
    this.ownerPicUrl = pItem["ownerPicUrl"];//所有者头像
    this.ownerSex = pItem["ownerSex"];//所有人性别
    this.status = pItem["status"];//状态(0->没抢/1->抢)
    this.kind = pItem["kind"];//种类
    this.isAutoGrab = pItem["isAutoGrab"];//是否自动抢
    this.qqi = pItem["qqi"];//亲亲指数
    return this;
};
mddBll.bombredpacketBean = function (pRedpacket) {
    this.id = pRedpacket["id"];//编号
    this.amount = pRedpacket["amount"];//获取金额
    this.count = pRedpacket["count"];//数量
    this.grabCount = pRedpacket["grabCount"];//已获取的份数
    this.version = pRedpacket["version"];//版本
    this.summary = pRedpacket["summary"];//显示文本
    this.time = pRedpacket["time"];//时间
    this.owner = pRedpacket["owner"];//所有者id
    this.ownerName = pRedpacket["ownerName"];//所有者姓名
    this.ownerPicUrl = pRedpacket["ownerPicUrl"];//所有者的图片
    this.sceneType = pRedpacket["sceneType"];//场景类型
    this.sceneKey = pRedpacket["sceneKey"];//场景key
    this.type = pRedpacket["type"];//类型
    this.status = pRedpacket["status"];//状态(1->没抢完,2->都抢完,3->被回收，时间到了没抢完)
    this.items = new Array();//列表
    for (var i = 0; i < pRedpacket["items"].length; i++) {
        var tIteam = pRedpacket["items"][i];
        this.items.push(new mddBll.bombItemsBean(tIteam));
    }
    return this;
};
//定义实体类
mddBll.bombBean = function (pObj) {
    //成员变量
    this.grabamount = pObj["grabamount"];//当前获取人的金额
    this.isGet = pObj["isGet"];//是否抢过当前红包
    this.isGrab = pObj["isGrab"];//当前红包是否被当前以外人抢过
    this.redpacket = new mddBll.bombredpacketBean(pObj["redpacket"]);//红包内容
    this.serverTime = pObj["serverTime"];//服务器时间
    return this;
};
//红包状态
mddBll.walletbalance = function (pObj) {
    //成员变量
    this.balance = pObj["balance"];
    this.WithDrawRule = pObj["WithDrawRule"];
    this.qqi = pObj["qqi"];
    this.QqiRule = pObj["QqiRule"];
    return this;
}
//指数炸弹红包
mddBll.pointBobm=new Object();
//指数炸弹红包
mddBll.pointBobm.snatcheitem=function(pItemArr)
{
    //获取uid
    this.uid=pItemArr[0];
    //获取的钱
    this.menoy=pItemArr[1];
    //时间
    this.create_at=pItemArr[2];
    return this;
};
//指数炸弹红包packet
mddBll.pointBobm.package=function(pRedpacket)
{
this.count=pRedpacket["count"];
this.create_at=pRedpacket["create_at"];
this.summary=pRedpacket["summary"];
this.amount=pRedpacket["amount"];
this.id=pRedpacket["id"];
this.owner_id=pRedpacket["owner_id"];
    return this;
}
//用户
mddBll.pointBobm.owner=function(pOwner)
{
this.first_name=pOwner["first_name"];
this.last_name=pOwner["last_name"];
this.uid=pOwner["uid"];
this.avatar=pOwner["avatar"];
this.real_name=pOwner["real_name"];
    return this;
}
//大的
mddBll.pointBobm.snatch_list=function(pObj)
{
this.got_bomb=pObj["got_bomb"];
this.snatches=new Array();
for (var i = 0; i < pObj["snatches"].length; i++) {
        var tIteam = pObj["snatches"][i];
        this.snatches.push(new mddBll.pointBobm.snatcheitem(tIteam));
}
this.ok=pObj["ok"];
this.SERVER_DOMAIN=pObj["SERVER_DOMAIN"];
this.package=new mddBll.pointBobm.package(pObj["package"]);
this.owner=new mddBll.pointBobm.owner(pObj["owner"]);
this.my_earn=pObj["my_earn"];
this.my_uid=pObj["my_uid"];
this.got_bomb_uid=pObj["got_bomb_uid"];
this.champion=pObj["champion"];
return this;
}
//炸弹状态包
mddBll.pointBobm.statebeanpackage=function(pPackage)
{
    if(pPackage!=undefined)
    {

    this.count=pPackage["count"];
    this.create_at=pPackage["create_at"];
    this.summary=pPackage["summary"];
    this.id=pPackage["id"];//炸弹id
    this.amount=pPackage["amount"];
    this.id=pPackage["id"];//你的页面的packeid?
    this.owner_id=pPackage["owner_id"];//炸弹所有者
    this.remains=pPackage["remains"];//剩余个数
    return this;
    }else{
        return undefined;
    }
}
//炸弹状态列表
mddBll.pointBobm.statebean=function(pObj)
{
    this.status=pObj["status"];
    this.remains=pObj["remains"];
    this.life_time=pObj["life_time"];
    this.got=pObj["got"];
    this.ok=pObj["ok"];
    this.package=new mddBll.pointBobm.statebeanpackage(pObj["package"]);

    return this;
}
//抢的炸弹返回值
mddBll.pointBobm.grapstatebean=function(pObj)
{
    this.ok=pObj["ok"];
    this.status=pObj["status"];
    this.life_time=pObj["life_time"];
    this.got=pObj["got"];
    this.package=new mddBll.pointBobm.statebeanpackage(pObj["package"]);
    this.error=pObj["error"];
    this.msg=pObj["msg"];
    return this;
}
//游戏异常
mddBll.pointBobm.errorState=function(pObj)
{
    this.ok=pObj["ok"];
    this.error=pObj["error"];
    this.msg=pObj["msg"];
    return this;
}


