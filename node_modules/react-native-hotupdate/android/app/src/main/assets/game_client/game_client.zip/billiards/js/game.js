function drawDesk() {}

//绘制母球
function drawPlayer() {
	if(playerBall.clear == false) {
		playerBall.move();
	}
}
//创建白球
function createWhite(x, y, r) {
	playerBall = {
		x: x,
		y: y,
		r: r,
		img: imgWhiteBall,
		speedX: 0,
		speedY: 0,
		speed: 0,
		type: 0,
		num: 0,
		clear: false,
		push: 0,
		prePush: 0,
		direction: 0,
		hitMenu: 0,
		hitMenuX: 0,
		hitMenuY: 0,
		hitMenuSeleX: 0,
		hitMenuSeleY: 0,
		freePlace: 1,
		firstCra: 0,
		move: function() {
			if(this.x <= ballDesk.width * 0.1167) {
				this.speedX = Math.abs(this.speedX);
			} else if(this.x >= ballDesk.width - this.r - this.r - ballDesk.width * 0.1167) {
				this.speedX = -1 * Math.abs(this.speedX);
			}
			if(this.y <= ballDesk.height * 0.0658) {
				this.speedY = Math.abs(this.speedY);
			} else if(this.y >= ballDesk.height - this.r - this.r - ballDesk.height * 0.0658) {
				this.speedY = -1 * Math.abs(this.speedY);
			}
			if(this.speedX > 0 && this.speedY >= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX -= moca * bili;
				this.speedY -= moca * (1 - bili);
				this.speedX <= 0 ? this.speedX = 0 : null;
				this.speedY <= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX > 0 && this.speedY <= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX -= moca * bili;
				this.speedY += moca * (1 - bili);
				this.speedX <= 0 ? this.speedX = 0 : null;
				this.speedY >= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX < 0 && this.speedY >= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX += moca * bili;
				this.speedY -= moca * (1 - bili);
				this.speedX >= 0 ? this.speedX = 0 : null;
				this.speedY <= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			} else if(this.speedX < 0 && this.speedY <= 0) {
				var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
				this.speedX += moca * bili;
				this.speedY += moca * (1 - bili);
				this.speedX >= 0 ? this.speedX = 0 : null;
				this.speedY >= 0 ? this.speedY = 0 : null;
				this.x += this.speedX;
				this.y += this.speedY;
			}
			ctx.drawImage(this.img, this.x, this.y, this.r * 2, this.r * 2);
			if(this.hitMenu == 1) {
				switch(this.prePush) {
					case 0:
						ctx.drawImage(xuanqu1, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 1:
						ctx.drawImage(xuanqu6, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 2:
						ctx.drawImage(xuanqu7, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 3:
						ctx.drawImage(xuanqu8, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 4:
						ctx.drawImage(xuanqu9, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 5:
						ctx.drawImage(xuanqu2, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 6:
						ctx.drawImage(xuanqu3, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 7:
						ctx.drawImage(xuanqu4, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					case 8:
						ctx.drawImage(xuanqu5, this.hitMenuX - this.r * 7.5, this.hitMenuY - this.r * 7.5, this.r * 15, this.r * 15)
						break;
					default:
						break;
				}
			}
			if(this.freePlace == 1) {
				ctx.drawImage(yiqiu, this.x - this.r, this.y - this.r, this.r * 4, this.r * 4)
			}

		}
	}
}
//绘制分数球
function drawScoreBall() {
	for(var i = 0; i < scoreBallArr.length; i++) {
		if(scoreBallArr[i].clear == false) {
			scoreBallArr[i].move();
		}
	}
}
//创建分数球
function createScoreBall(positions) {
	 var scoreBall1 = new ScoreBall(positions[0][0] * ballDesk.width / 100, positions[0][1] * ballDesk.width / 100, 1, ballR, ballImg1);
 	var scoreBall2 = new ScoreBall(positions[1][0] * ballDesk.width / 100, positions[1][1] * ballDesk.width / 100, 2, ballR, ballImg2);
 	var scoreBall3 = new ScoreBall(positions[2][0] * ballDesk.width / 100, positions[2][1] * ballDesk.width / 100, 3, ballR, ballImg3);
 	var scoreBall4 = new ScoreBall(positions[3][0] * ballDesk.width / 100, positions[3][1] * ballDesk.width / 100, 4, ballR, ballImg4);
 	var scoreBall5 = new ScoreBall(positions[4][0] * ballDesk.width / 100, positions[4][1] * ballDesk.width / 100, 5, ballR, ballImg5);
 	var scoreBall6 = new ScoreBall(positions[5][0] * ballDesk.width / 100, positions[5][1] * ballDesk.width / 100, 6, ballR, ballImg6);
	var scoreBall7 = new ScoreBall(positions[6][0] * ballDesk.width / 100, positions[6][1] * ballDesk.width / 100, 7, ballR, ballImg7);
 	var scoreBall8 = new ScoreBall(positions[7][0] * ballDesk.width / 100, positions[7][1] * ballDesk.width / 100, 8, ballR, ballImg8);
 	var scoreBall9 = new ScoreBall(positions[8][0] * ballDesk.width / 100, positions[8][1] * ballDesk.width / 100, 9, ballR, ballImg9);
	scoreBallArr.push(scoreBall1);
	scoreBallArr.push(scoreBall2);
	scoreBallArr.push(scoreBall3);
	scoreBallArr.push(scoreBall4);
	scoreBallArr.push(scoreBall5);
	scoreBallArr.push(scoreBall6);
	scoreBallArr.push(scoreBall7);
	scoreBallArr.push(scoreBall8);
	scoreBallArr.push(scoreBall9);
}

function ScoreBall(x, y, num, r, img) {
	this.x = x;
	this.y = y;
	this.r = r;
	this.speedX = 0;
	this.speedY = 0;
	this.img = img;
	this.type = 2;
	this.num = num;
	this.clear = false;
}
ScoreBall.prototype.move = function() {
		if(this.x <= ballDesk.width * 0.1167) {
			this.speedX = Math.abs(this.speedX);
		} else if(this.x >= ballDesk.width - this.r - this.r - ballDesk.width * 0.1167) {
			this.speedX = -1 * Math.abs(this.speedX);
		}
		if(this.y <= ballDesk.height * 0.0658) {
			this.speedY = Math.abs(this.speedY);
		} else if(this.y >= ballDesk.height - this.r - this.r - ballDesk.height * 0.0658) {
			this.speedY = -1 * Math.abs(this.speedY);
		}
		if(this.speedX > 0 && this.speedY > 0) {
			var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
			this.speedX -= moca * bili;
			this.speedY -= moca * (1 - bili);
			this.speedX <= 0 ? this.speedX = 0 : null;
			this.speedY <= 0 ? this.speedY = 0 : null;
			this.x += this.speedX;
			this.y += this.speedY;
		} else if(this.speedX > 0 && this.speedY < 0) {
			var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
			this.speedX -= moca * bili;
			this.speedY += moca * (1 - bili);
			this.speedX <= 0 ? this.speedX = 0 : null;
			this.speedY >= 0 ? this.speedY = 0 : null;
			this.x += this.speedX;
			this.y += this.speedY;
		} else if(this.speedX < 0 && this.speedY > 0) {
			var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
			this.speedX += moca * bili;
			this.speedY -= moca * (1 - bili);
			this.speedX >= 0 ? this.speedX = 0 : null;
			this.speedY <= 0 ? this.speedY = 0 : null;
			this.x += this.speedX;
			this.y += this.speedY;
		} else if(this.speedX < 0 && this.speedY < 0) {
			var bili = Math.abs(this.speedX) / Math.abs(Math.abs(this.speedX) + Math.abs(this.speedY));
			this.speedX += moca * bili;
			this.speedY += moca * (1 - bili);
			this.speedX >= 0 ? this.speedX = 0 : null;
			this.speedY >= 0 ? this.speedY = 0 : null;
			this.x += this.speedX;
			this.y += this.speedY;
		}
		ctx.drawImage(this.img, this.x, this.y, this.r * 2, this.r * 2);
	}
	// 碰撞检测
function jugeCrash(obj1, obj2) {
	var spaceBall = Math.sqrt((obj1.x - obj2.x) * (obj1.x - obj2.x) + (obj1.y - obj2.y) * (obj1.y - obj2.y));
	var canCrash = true;
	var index = -1;
	for(var l = 0; l < crashClear.length; l++) {
		if(crashClear[l][0] == obj1.num && crashClear[l][1] == obj2.num) {
			canCrash = false;
			index = l;
		}
	}
	if(spaceBall < (obj1.r + obj2.r) * 0.9 && canCrash == true) {
		crashClear.push([obj1.num, obj2.num]);
		//撞了！！
		var v1x = obj1.speedX;
		var v1y = obj1.speedY;
		var v2x = obj2.speedX;
		var v2y = obj2.speedY;
		var x1 = obj1.x;
		var x2 = obj2.x;
		var y1 = obj1.y;
		var y2 = obj2.y;
		var addx = ((v1x - v2x) * (x1 - x2) * (x1 - x2) + (v1y - v2y) * (x1 - x2) * (y1 - y2)) / ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
		var addy = ((v1y - v2y) * (y1 - y2) * (y1 - y2) + (v1x - v2x) * (x1 - x2) * (y1 - y2)) / ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
		obj1.speedX = v1x - addx;
		obj1.speedY = v1y - addy;
		obj2.speedX = v2x + addx;
		obj2.speedY = v2y + addy;
		if(obj1.num == 0 && obj1.freePlace == 0) {
			playerBall.direction = angle(0, 0, playerBall.speedX, playerBall.speedY);
			playerBall.speed = Math.sqrt(playerBall.speedX * playerBall.speedX + playerBall.speedY * playerBall.speedY);
			switch(obj1.push) {
				case 7:
					playerBall.direction -= 15;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					break;
				case 3:
					playerBall.direction += 15;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					break;
				case 1:
					playerBall.direction += 0;
					playerBall.speedX += v1x * 0.6;
					playerBall.speedY += v1y * 0.6;
					break;
				case 5:
					playerBall.direction -= 0;
					playerBall.speedX -= v1y * 0.6;
					playerBall.speedY -= v1y * 0.6;
					break;
				case 2:
					playerBall.direction += 10;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					playerBall.speedX += v1x * 0.4;
					playerBall.speedY += v1y * 0.4;
					break;
				case 4:
					playerBall.direction += 10;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					playerBall.speedX -= v1x * 0.4;
					playerBall.speedY -= v1y * 0.4;
					break;
				case 8:
					playerBall.direction -= 10;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					playerBall.speedX += v1x * 0.4;
					playerBall.speedY += v1y * 0.4;
					break;
				case 6:
					playerBall.direction -= 10;
					playerBall.speedX = playerBall.speed * Math.cos(playerBall.direction * Math.PI / 180);
					playerBall.speedY = playerBall.speed * Math.sin(playerBall.direction * Math.PI / 180);
					playerBall.speedX -= v1x * 0.4;
					playerBall.speedY -= v1y * 0.4;
					break;
				default:
					break;
			}
			playerBall.push = 0;
			playerBall.firstCra == 0 ? playerBall.firstCra = obj2.num : null;
		}

	} else if(spaceBall > (obj1.r + obj2.r) && canCrash == false) {
		crashClear.splice(index, 1);
	}
}
//创建进洞球
function CoreBall(x, y) {
	this.x = x;
	this.y = y;
	this.r = ballDesk.width * 0.05;
	this.type = 10;
}
CoreBall.prototype.move = function() {
	ctx.beginPath();
	ctx.fillStyle = "red";
	ctx.arc(this.x + this.r, this.y + this.r, this.r, 0, Math.PI * 2, false);
	ctx.fill();
}

//function createCoreBall() {
//	// 创建六个分数球
//	alert(1);
//	var ball_core_1 = new CoreBall(ballDesk.width * 0.05555, ballDesk.width * 0.06666);
//	var ball_core_2 = new CoreBall(ballDesk.width * 0.84444, ballDesk.width * 0.06666);
//	var ball_core_3 = new CoreBall(ballDesk.width * 0.03555, ballDesk.height * 0.5 - ballDesk.width * 0.05);
//	var ball_core_4 = new CoreBall(ballDesk.width * 0.86444, ballDesk.height * 0.5 - ballDesk.width * 0.05);
//	var ball_core_5 = new CoreBall(ballDesk.width * 0.05555, ballDesk.height - ballDesk.width * 0.16666);
//	var ball_core_6 = new CoreBall(ballDesk.width * 0.84444, ballDesk.height - ballDesk.width * 0.16666);
//	scoreBalls.push(ball_core_1);
//	scoreBalls.push(ball_core_2);
//	scoreBalls.push(ball_core_3);
//	scoreBalls.push(ball_core_4);
//	scoreBalls.push(ball_core_5);
//	scoreBalls.push(ball_core_6);
//}
//判断进洞
function getScore() {
	for(var i = 0; i < ballAllArr.length; i++) {
		for(var j = 0; j < scoreBalls.length; j++) {
			var obj1 = ballAllArr[i];
			var obj2 = scoreBalls[j];
			var spaceBall = Math.sqrt((obj1.x - obj2.x) * (obj1.x - obj2.x) + (obj1.y - obj2.y) * (obj1.y - obj2.y));
			if(spaceBall <= obj2.r + obj1.r && playerBall.freePlace == 0) {
				//				alert(1);
				obj1.clear = true;
				ballIn.push(obj1.num);
			}
		}
	}
}

function jugeCraAll() {
	for(var i = 0; i < ballAllArr.length; i++) {
		if(ballAllArr[i].clear == true) {
			var sco = ballAllArr[i].num;
			ballAllArr.splice(i, 1);
			i--;
			if(sco != 0){
				occMessage(sco+"号球进，得分"+sco,ballColor[sco - 1]);
			}
		}
	}
	for(var i = 0; i < ballAllArr.length; i++) {
		for(var j = i + 1; j < ballAllArr.length; j++) {
			jugeCrash(ballAllArr[i], ballAllArr[j]);
		}
	}
}

function hitFunc() {
	ballDesk.canHit = true;
	ballDesk.addEventListener("touchend", function(e) {
		e.preventDefault();
//		if(ballDesk.canHit == true && ballDesk.canDrawLine == true && e.touches.length == 0 && playerBall.freePlace == 0 && master == 1) {
//			playerBall.push = playerBall.prePush;
//			var disX = this.x - playerBall.r - playerBall.x;
//			var disY = this.y - playerBall.r - playerBall.y;
//			var direc = angle(0, 0, -disX, -disY);
////			var dis = Math.sqrt(disX*disX+disY*disY);
////			var nowDis = Math.sqrt((e.touches[0].clientX - playerBall.r - playerBall.x) * (e.touches[0].clientX - playerBall.r - playerBall.x) + (e.touches[0].clientY - playerBall.r - playerBall.y)*(e.touches[0].clientY - playerBall.r - playerBall.y));
////			//撞击速度，需要加入力度条
////			disDis = nowDis - dis;
////			disDis < playerBall.r*1.5?disDis = playerBall.r*1.5:null;
////			disDis > plauerBall.r*6?disDis = playerBall.r*6:null;
//			var speedAuto = 5 + 20 * (disDis/(playerBall.r*6));
//			console.log(disDis);
//			playerBall.speedX = speedAuto * Math.cos(direc * Math.PI / 180);
//			playerBall.speedY = speedAuto * Math.sin(direc * Math.PI / 180);
//			ballDesk.canDrawLine = false;
//			ballDesk.canHit = false;
//			ballDesk.min = returnMinNum();
//			preScore = ballIn.length;
//		}
		if(ballDesk.canHit == true && ballDesk.canDrawLine == true && e.touches.length == 1 && playerBall.freePlace == 0) {
			playerBall.hitMenu = 0;
		}
		var num = 0;
		for(var i = 1 ; i < ballAllArr.length;i++){
			var dis = Math.sqrt((ballAllArr[i].x - playerBall.x)*(ballAllArr[i].x - playerBall.x) + (ballAllArr[i].y - playerBall.y)*(ballAllArr[i].y - playerBall.y));
			if(dis > playerBall.r*1.6){
				num ++ ;
			}
		}
		if(playerBall.freePlace == 1 && num == ballAllArr.length -1) {
			playerBall.freePlace = 0;
			ballDesk.canDrawLine = false;
			crashClear = [];
		}
	}, false);
}
//辅助线
function makeTipLine() {
	ballDesk.canDrawLine = false;
	ballDesk.addEventListener("touchstart", function(e) {
		e.preventDefault();
		if(ballDesk.canHit == true) {
			ballDesk.canDrawLine = true;
			this.x = e.touches[0].clientX;
			this.y = e.touches[0].clientY;
			this.preX = e.touches[0].clientX;
			this.preY = e.touches[0].clientY;
		}
		if(e.touches.length == 2) {
			playerBall.hitMenu = 1;
			playerBall.hitMenuX = e.touches[1].clientX;
			playerBall.hitMenuY = e.touches[1].clientY;
			playerBall.hitMenuSeleX = e.touches[1].clientX;
			playerBall.hitMenuSeleY = e.touches[1].clientY;
			playerBall.prePush = 0;
		}
	}, false)
	ballDesk.addEventListener("touchmove", function(e) {
		e.preventDefault();
		this.x = e.touches[0].clientX - ballDesk.offsetLeft;
		this.y = e.touches[0].clientY - ballDesk.offsetTop;
//		if(master == 1 && playerBall.freePlace != 1){
//			var disX = this.x - playerBall.r - playerBall.x;
//			var disY = this.y - playerBall.r - playerBall.y;
//			var direc = angle(0, 0, -disX, -disY);
//			var dis = Math.sqrt((this.preX- playerBall.r - playerBall.x) * (this.preX- playerBall.r - playerBall.x) + (this.preY - playerBall.r - playerBall.y)*(this.preY - playerBall.r - playerBall.y));
//			var nowDis = Math.sqrt((e.touches[0].clientX - playerBall.r - playerBall.x) * (e.touches[0].clientX - playerBall.r - playerBall.x) + (e.touches[0].clientY - playerBall.r - playerBall.y)*(e.touches[0].clientY - playerBall.r - playerBall.y));
//			//撞击速度，需要加入力度条
//			disDis = nowDis - dis;
//			disDis < playerBall.r*1.5?disDis = playerBall.r*1.5:null;
//			disDis > playerBall.r*6?disDis = playerBall.r*6:null;
//		}
		if(playerBall.freePlace == 1) {
			playerBall.x = e.touches[0].clientX - playerBall.r - ballDesk.offsetLeft * 2;
			playerBall.y = e.touches[0].clientY - playerBall.r - ballDesk.offsetTop * 2;
			if(playerBall.x <= ballDesk.width * 0.1167) {
				playerBall.x = ballDesk.width * 0.1167;
			} else if(playerBall.x >= ballDesk.width - playerBall.r - playerBall.r - ballDesk.width * 0.1167) {
				playerBall.x = ballDesk.width - playerBall.r - playerBall.r - ballDesk.width * 0.1167;
			}
			if(playerBall.y <= ballDesk.height * 0.0658) {
				playerBall.y = ballDesk.height * 0.0658;
			} else if(playerBall.y >= ballDesk.height - playerBall.r - playerBall.r - ballDesk.height * 0.0658) {
				playerBall.y = ballDesk.height - playerBall.r - playerBall.r - ballDesk.height * 0.0658;
			}
		}
//		if(playerBall.hitMenu == 1) {
//			playerBall.hitMenuSeleX = e.touches[1].clientX;
//			playerBall.hitMenuSeleY = e.touches[1].clientY;
//			var menuDis = Math.sqrt((playerBall.hitMenuSeleX - playerBall.hitMenuX) * (playerBall.hitMenuSeleX - playerBall.hitMenuX) + (playerBall.hitMenuSeleY - playerBall.hitMenuY) * (playerBall.hitMenuSeleY - playerBall.hitMenuY));
//			var hitAngle = angle(playerBall.hitMenuX, playerBall.hitMenuY, playerBall.hitMenuSeleX, playerBall.hitMenuSeleY);
////			console.log(hitAngle);
//			if(menuDis <= playerBall.r * 2.5) {
//				playerBall.prePush = 0;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle <= 22.5 && hitAngle > -22.5) {
//				playerBall.prePush = 3;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 22.5 && hitAngle < 67.5) {
//				playerBall.prePush = 4;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 67.5 && hitAngle < 112.5) {
//				playerBall.prePush = 5;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 112.5 && hitAngle < 157.5) {
//				playerBall.prePush = 6;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 157.5 && hitAngle < 202.5) {
//				playerBall.prePush = 7;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 202.5 && hitAngle < 247.5) {
//				playerBall.prePush = 8;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= -67.5 && hitAngle < -22.5) {
//				playerBall.prePush = 2;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle >= 247.5) {
//				playerBall.prePush = 1;
//			} else if(menuDis > playerBall.r * 2.5 && hitAngle < -67.5) {
//				playerBall.prePush = 1;
//			}
//
//		}
	}, false);
}

function drawTipLine() {
	var num = 0;
	var len = ballAllArr.length;
	for(var i = 0; i < len; i++) {
		if(ballAllArr[i].speedX == 0 && ballDesk.canHit == false) {
			num++;
		}
	}
	if(num == len) {
		//单次挥杆结束
		ballDesk.canHit =true;
		if(playerBall.firstCra == 0) {
			console.log("没碰到球");
			game = false;
			tip = "没有碰到球，加把力试试看！"
		}
		if(preScore == ballIn.length && playerBall.firstCra != 0) {
			console.log("没有球进");
			game = false;
			tip = "很遗憾没有进球"
		}
		if(playerBall.firstCra != 0 && playerBall.firstCra != ballDesk.min) {
			console.log("游戏结束");
			game = false;
			tip = "请保证母球率先碰到场上最小球才算击球成功"
		}
		playerBall.firstCra = 0;

	}
	if(ballDesk.canDrawLine == true && playerBall.freePlace == 0) {
		ctx.moveTo(ballDesk.x, ballDesk.y);
		ctx.strokeStyle = "red";
		ctx.fillStyle = "#55A07B";
		//		ctx.moveTo(playerBall.x+playerBall.r,playerBall.y+playerBall.r);
		//		ctx.lineTo(playerBall.x + playerBall.r, playerBall.y + playerBall.r);
		var arr = calculate() || [playerBall.x + playerBall.r, playerBall.y + playerBall.r];
		ctx.stroke();
		drawDot(arr[0], arr[1]);
		ctx.moveTo(arr[0] + playerBall.r, arr[1]);
		ctx.arc(arr[0], arr[1], ballR * 0.82, 0, Math.PI * 2, false);
		ctx.fill();
		ctx.save();
		ctx.translate(playerBall.x + playerBall.r, playerBall.y + playerBall.r);
		var dire = angle(playerBall.x + playerBall.r, playerBall.y + playerBall.r, arr[0], arr[1]) + 90;
		ctx.rotate(dire * Math.PI / 180);
		//111111
		ctx.drawImage(gan, -playerBall.r * 0.42, disDis, playerBall.r * 0.84, playerBall.r * 26.5);
		ctx.restore();
	}
}

function calculate() {
	var bili = Math.abs((playerBall.x + playerBall.r - ballDesk.x) / (playerBall.y + playerBall.r - ballDesk.y));
	var sqrt = Math.sqrt(1 + bili * bili);
	var sinx = (bili / sqrt) * (playerBall.x + playerBall.r - ballDesk.x) / Math.abs(playerBall.x + playerBall.r - ballDesk.x);
	var siny = 1 / sqrt * (playerBall.y + playerBall.r - ballDesk.y) / Math.abs(playerBall.y + playerBall.r - ballDesk.y);
	var oriX = playerBall.x + playerBall.r;
	var oriY = playerBall.y + playerBall.r;
	if(playerBall.y + playerBall.r - ballDesk.y == 0) {
		if(playerBall.x + playerBall.r >= ballDesk.x) {
			sinx = 1;
			siny = 0;
		} else {
			sinx = -1;
			siny = 0;
		}
	}
	sinx *= 5;
	siny *= 5;
	while(oriX < ballDesk.width && oriY < ballDesk.height && oriX > playerBall.r && oriY > playerBall.r) {
		oriX += sinx;
		oriY += siny;
		for(var i = 1; i < ballAllArr.length; i++) {
			var spaceDis = Math.sqrt((oriX - ballAllArr[i].x - ballAllArr[i].r) * (oriX - ballAllArr[i].x - ballAllArr[i].r) + (oriY - ballAllArr[i].y - ballAllArr[i].r) * (oriY - ballAllArr[i].y - ballAllArr[i].r));
			if(spaceDis < (ballAllArr[i].r + playerBall.r) * 0.82) {
				return [oriX, oriY];
			}
			if(oriX > ballDesk.width - playerBall.r - ballDesk.width * 0.1167 || oriY > ballDesk.height - playerBall.r - ballDesk.height * 0.0658 || oriX < playerBall.r + ballDesk.width * 0.1167 || oriY < playerBall.r + ballDesk.height * 0.0658) {
				return [oriX, oriY];
			}
		}
	}
}

function angle(x1, y1, x2, y2) {
	var diff_x = x2 - x1,
		diff_y = y2 - y1;
	//返回角度,不是弧度
	if(diff_x < 0) {
		return 360 * Math.atan(diff_y / diff_x) / (2 * Math.PI) + 180;
	} else {
		return 360 * Math.atan(diff_y / diff_x) / (2 * Math.PI);
	}
}

function drawDot(a, b) {
	var dotArr = [];
	var dis = Math.sqrt((a - playerBall.x - playerBall.r) * (a - playerBall.x - playerBall.r) + (b - playerBall.y - playerBall.r) * (b - playerBall.y - playerBall.r));
	var lineDire = angle(playerBall.x + playerBall.r, playerBall.y + playerBall.r, a, b);
	var num = parseInt(dis / 30);
	for(var i = 1; i < num; i++) {
		ctx.beginPath();
		ctx.fillStyle = "#55A07B";
		ctx.arc((playerBall.x + playerBall.r + 30 * i * Math.cos(lineDire * Math.PI / 180)), (playerBall.y + playerBall.r + 30 * i * Math.sin(lineDire * Math.PI / 180)), 5, 0, Math.PI * 2, false);
		ctx.fill();
		ctx.closePath();
	}
}

function score() {
	if(ballInlen != ballIn.length &&playerBall.firstCra == ballDesk.min ) {
		scoreAll = 5;
		for(var i = 0; i < ballIn.length; i++) {
			scoreAll += parseInt(ballIn[i]);
			if(ballIn[i] == 0) {
				console.log("母球进洞")
				game = false;
				tip = "请尽量避免母球进洞";
			}
			if(ballIn[i] == 9){
				scoreAll = 50;
				game = false;
			}
		}
		scoreAll >50?scoreAll = 50:null;
		console.log(preScore);
		var scoreDiv = document.querySelector(".score");
		var _preScore = preScore;
		scoreDiv.timer =  setInterval(function(){
			if(_preScore == scoreAll){
				clearInterval(scoreDiv.timer);
				scoreDiv.innerHTML = "得分：" + scoreAll;
			}else {
				_preScore ++;
				scoreDiv.innerHTML = "得分：" + _preScore;
			}
		},100)
	}
	ballInlen = ballIn.length;
}

function returnMinNum() {
	var min = 10;
	for(var i = 1; i < ballAllArr.length; i++) {
		ballAllArr[i].num <= min ? min = ballAllArr[i].num : null;
	}
	return min;
}

function gameEnd() {
	if(game == false && submitScore == true) {
		var winning = "";
		if(scoreAll == 50){
			winning = "on";
		}
		loadXMLDoc('/game_server/billiards/'+gameId+'/submit_score/',function(data){
			clearInterval(gameTimer);
			document.querySelector(".gameEnd").style.display = "flex";
			console.log(preScore);
			document.querySelector(".gameEnd").innerHTML = '<p>游戏结束</p><p>本局得分：' + scoreAll + '</p><p>'+tip+'</p><p onclick="restart()">再来一局</p><p onclick="exit()">退出</p>';			
                        result = JSON.parse(data);
                        if (result.ok != true) {
                            alert(data);
                        }
		},{
			winning: winning,
          	score:scoreAll,
          	replay: ""
		})
		submitScore = false;
	}
	
}
function restart(){
	location.reload();
}
