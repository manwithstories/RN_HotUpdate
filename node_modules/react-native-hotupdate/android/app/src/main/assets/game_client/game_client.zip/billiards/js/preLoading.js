var body = document.getElementsByTagName("body")[0]; //HTMLBodyDOMObject
var containerSign = document.querySelector(".containerSign"); //首页
var container = document.querySelector(".container"); //游戏页
var ballDesk = document.querySelector('#ballDesk'); //canvas对象
var ctx = ballDesk.getContext("2d"); //canvas画布
var wrap = document.querySelector(".wrap"); //预加载动画
var gameDeskData = {
	widthPng: 1242,
	heightPng: 2208,
}
//canvas拉伸倍率
var imgSrc = ["img/nine/desk.png", "img/nine/QIUmu.png", "img/nine/QIU1.png", "img/nine/QIU2.png", "img/nine/QIU3.png", "img/nine/QIU4.png", "img/nine/QIU5.png", "img/nine/QIU6.png", "img/nine/QIU7.png", "img/nine/QIU8.png", "img/nine/QIU9.png", "img/nine/background.jpg", "img/nine/yiqiu.png", "img/nine/gan.png","img/nine/JQWZan.png","img/nine/JQWZanD.png","img/nine/JQWZqiu.png","img/nine/JQWZqiuD.png"];
var imgLoadArr = []; //预加载图片调用
var imgNum = 0; //预加载数目
var gameTimer = null; //帧数渲染
var playerBall = null; //母球对象
var scoreBallArr = []; //分数球数组
var scoreBalls = []; //球洞
var ballAllArr = []; //保存所有球对象
var master = 0; //操作方式
var disDis = 50; //击球力度初始化
var crashClear = []; //防止连续碰撞检测
var preScore = 0;
var preScoreNum = 0;
var ballIn = []; //进洞球数组
var ganAnimate = false;//球杆动画 -----
var ballInlen = 0;
var game = true;
var gameId = 0;
var submitScore = true;
var scoreAll = 0;
var animateTimer = 0;
var	stoped = false;
var allMove = false; //-----
var getscorestatus = false; //-----
var dragstatus = false; //-----
var caculateCache = [];
var caculateBechange = false;
var commit = false;
var gameNumControl = 0;
var xxxxx = 0.5;
//document.querySelector(".score").innerHTML = xxxxx;
//var gameDeskData = {
//	widthPng: 1242,
//	heightPng: 2208,
//}
gameDeskData["widthPng"] *= xxxxx;
gameDeskData["heightPng"] *= xxxxx;
var scale = setScreen(); 
var moca = 0.4; //球板摩擦力
var addScore = 0;
//预加载
function preLoading() {
	body.style.width = window.innerWidth + "px";
	body.style.height = window.innerHeight + "px";
	wrap.style.display = "block";
	wrap.style.left = (body.offsetWidth - 100) / 2;
//	container.style.webkitTransform = "scale(" + (1 / scale) + "," + (1 / scale) + ")";
//	container.style.transform = "scale(" + (1 / scale) + "," + (1 / scale) + ")";
	container.style.width = window.innerWidth  + "px";
	container.style.height = window.innerHeight  + "px";
	var imgNum = 0;
	for(var i = 0; i < imgSrc.length; i++) {
		var img = new Image();
		img.src = imgSrc[i];
		imgLoadArr.push(img);
		img.onload = function() {
			imgNum++;
			wrap.querySelector(".floadp").innerHTML = parseInt(100 * imgNum / imgSrc.length) + "%";
			if(imgNum == imgSrc.length ) {
				//预加载完毕
//				wrap.style.display = "none";
//				document.write("settimeout111");
				setTimeout(function(){
					if(wrap.parentNode)
					wrap.parentNode.removeChild(wrap);
					
//					document.write("settimeout");
					container.style.display = "block";
					container.style.backgroundImage = "url(" + imgLoadArr[11].src + ")";
					ballDesk.style.backgroundImage = "url(" + imgLoadArr[0].src + ")";
					ballDesk.style.backgroundSize = "100% 100%";
//					setScreen();
					setScreenDOM();
					hitFunc();
					makeTipLine();
				},0)
//				createCoreBall();
			}
		}
	}
}
//计算屏幕大小得到缩放比例
function setScreen() {
	var width = 300;
	var height = 300;
	while(width < window.innerWidth && height < window.innerHeight) {
		width++;
		height = (width / gameDeskData.widthPng) * gameDeskData.heightPng;
	}
	return [gameDeskData.widthPng / width,width,height];
}

function setScreenDOM() {
	document.getElementsByTagName("html")[0].style.fontSize = window.innerWidth / 20 + "px";
	ballDesk.width = gameDeskData.widthPng;
	ballDesk.height = gameDeskData.heightPng;
	ballDesk.style.width = scale[1] + "px";
	ballDesk.style.height = scale[2] + "px";
	var proBle = document.querySelector(".proBle");
	proBle.style.width = ballDesk.offsetWidth * 0.7 + "px";
	proBle.style.height = ballDesk.offsetWidth * 0.1 + "px";
	proBle.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth * 0.15 + "px";
	proBle.style.fontSize = ballDesk.offsetWidth * 0.05 + "px";
	var strengh = document.querySelector(".strengh");
	strengh.style.display = "block";
	strengh.style.width = ballDesk.offsetWidth * 0.1 + "px";
	strengh.style.height = ballDesk.offsetWidth * 0.7 + "px";
	strengh.style.top = ballDesk.offsetHeight * 0.525 + "px";
	var drag = strengh.querySelector(".drag");
	var dragDiv = strengh.querySelector(".dragDiv");
	dragDiv.canMove = false;
//	dragDiv.addEventListener("touchstart",function(){
//		 if(ballDesk.canDrawLine == true){
//		 	gameTimer = requestAnimationFrame(render);
//		 	ganAnimate = true;
//		 }
//	},false);
	dragDiv.addEventListener("touchmove", function(e) {
		e.preventDefault();
		if(ballDesk.canDrawLine == true && master == 0) {
			ganAnimate = true;
			dragDiv.top = e.touches[0].clientY - ballDesk.offsetHeight / 2 - ballDesk.offsetWidth * 0.04;
			dragDiv.top > 0 ? null : dragDiv.top = 0;
			dragDiv.top < 6.2 * ballDesk.offsetWidth * 0.1 ? null : dragDiv.top = 6.2 * ballDesk.offsetWidth * 0.1;
			dragDiv.style.top = dragDiv.top + "px";
			drag.style.height = dragDiv.top + "px";
			this.canMove = true;
			disDis = (dragDiv.top / (0.62 * ballDesk.width)) * playerBall.r * 5 + playerBall.r;
			disDis < playerBall.r * 1.5 ? disDis = playerBall.r * 1.5 : null;
			disDis > playerBall.r * 6 ? disDis = playerBall.r * 6 : null;
		}
	}, false);
	dragDiv.addEventListener("touchend", function() {
		var disX = ballDesk.x - playerBall.r - playerBall.x;
		var disY = ballDesk.y - playerBall.r - playerBall.y;
		var direc = angle(0, 0, (-1*disX), (-1*disY));
		//*********************
//		gameTimer = requestAnimationFrame(render);
		//撞击速度，需要加入力度条
		var speedAuto = 25 * (dragDiv.offsetTop / (0.62 * ballDesk.offsetWidth));
//		var speedAuto = 75 * (dragDiv.offsetTop / (0.62 * ballDesk.offsetWidth));
		if(speedAuto >= 1 && this.canMove == true && master == 0) {
			ballDesk.canDrawLine = false;
			ballDesk.canHit = false;
			ballDesk.min = returnMinNum();
			preScoreNum = ballIn.length;
			this.canMove = false;
			var timer = setInterval(function(){
				disDis-=playerBall.r*0.4;
				if(disDis <= playerBall.r){
					playerBall.speedX = speedAuto * Math.cos(direc * Math.PI / 180)*2;
					playerBall.speedY = speedAuto * Math.sin(direc * Math.PI / 180)*2;
					clearInterval(timer);
					timer = null;
					ganAnimate = false;
					gameNumControl ++;
				}
			},30);
			document.querySelector(".dot").style.left = "3rem";
			document.querySelector(".dot").style.top = "3rem";
			dragDiv.style.top = "0%";
			drag.style.height = "0px";
		}
	}, false);
	var exp = document.querySelector(".exp");
	var explain = document.querySelector(".explain");
	exp.loading = false;
	exp.addEventListener("touchstart",function(e){
		if(exp.loading == false){
			exp.loading = true;
			setTimeout(function(){
				explain.style.display = "block";
				exp.loading = false;
			},0)
		}
	},false);
	var close = document.querySelector(".close");
	close.style.right = ballDesk.offsetWidth*0.1 + "px";
	close.style.top = ballDesk.offsetWidth*0.1 + "px";
	close.loading = false;
	close.addEventListener("touchstart",function(){
		if(close.loading == false){
			close.loading = true;
			setTimeout(function(){
				explain.style.display = "none";
				close.loading = false;
			},0)
		}
	},false);
	var menu = document.querySelector(".menu");
	menu.style.width = ballDesk.offsetWidth*scale[0]/xxxxx + "px";
	menu.style.height = ballDesk.offsetHeight*scale[0]/xxxxx + "px";
	menu.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menu.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menu.style.left = ballDesk.offsetLeft + "px";
	var anD = document.querySelector(".JQWZan");
	anD.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth*0.5 - 59+"px";
	anD.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	anD.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	anD.occ = false;
	anD.loading = false;
	anD.addEventListener("touchstart",function(){
		var shadowDot = document.querySelector(".shadowDotMenu");
		if(anD.occ == false && anD.loading == false){
			anD.loading = true;
			setTimeout(function(){
				shadowDot.style.display = "block";
				anD.loading = false;
			},0)
			anD.occ = true;
		}else if(anD.occ == true && anD.loading == false) {
			anD.loading = true;
			setTimeout(function(){
				shadowDot.style.display = "none";
				anD.loading = false;
			},0)
			anD.occ = false;
		}
	},false);
	var shadowDot = document.querySelector(".shadowDotMenu");
	shadowDot.loading = false;
	document.querySelector(".shadowDotMenu").addEventListener("touchstart",function(){
		if(shadowDot.loading == false){
			shadowDot.loading = true;
			setTimeout(function(){
				this.style.display = "none";
				anD.occ = false;
				shadowDot.loading = false;
			},0);
		}
	},false) 
	var seleMenu = document.querySelector(".seleMenu");
	seleMenu.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth/2 - window.innerWidth/4 + "px";
	var ricl = document.querySelector(".ricl");
	ricl.addEventListener("touchstart",function(e){
		e.stopPropagation();
		e.preventDefault();
		var dot = ricl.querySelector(".dot");
//		console.log(e.touches[0].clientX)
		var left = e.touches[0].clientX - ricl.offsetLeft - seleMenu.offsetLeft-dot.offsetWidth/2;
		var top = e.touches[0].clientY - ricl.offsetTop - seleMenu.offsetTop-dot.offsetWidth/2;
		left > ballDesk.offsetWidth*6/20 ? left = ballDesk.offsetWidth*6/20:null;
		left < 0? left = 0 :null;
		top > ballDesk.offsetWidth*6/20 ? top = ballDesk.offsetWidth*6/20:null;
		top < 0? top = 0 :null;
		dot.style.left = left + "px";
		dot.style.top = top + "px";
//		console.log([dot.offsetLeft,dot.offsetTop]);
		playerBall.prePushDirection = angle(ballDesk.offsetWidth*3/20,ballDesk.offsetWidth*3/20,dot.offsetLeft,dot.offsetTop);
		playerBall.push = Math.sqrt((dot.offsetLeft - ballDesk.offsetWidth*3/20)*(dot.offsetLeft - ballDesk.offsetWidth*3/20) + (dot.offsetTop - ballDesk.offsetWidth*3/20)*(dot.offsetTop - ballDesk.offsetWidth*3/20))/(ballDesk.offsetWidth*3/20);
	},false);
	ricl.addEventListener("touchmove",function(e){
		e.stopPropagation();
		e.preventDefault();
		var dot = ricl.querySelector(".dot");
//		console.log(e.touches[0].clientX)
		var left = e.touches[0].clientX - ricl.offsetLeft - seleMenu.offsetLeft-dot.offsetWidth/2;
		var top = e.touches[0].clientY - ricl.offsetTop - seleMenu.offsetTop-dot.offsetWidth/2;
		left > ballDesk.offsetWidth*6/20 ? left = ballDesk.offsetWidth*6/20:null;
		left < 0? left = 0 :null;
		top > ballDesk.offsetWidth*6/20 ? top = ballDesk.offsetWidth*6/20:null;
		top < 0? top = 0 :null;
		dot.style.left = left + "px";
		dot.style.top = top + "px";
//		console.log([dot.offsetLeft,dot.offsetTop]);
		playerBall.prePushDirection = angle(ballDesk.offsetWidth*3/20,ballDesk.offsetWidth*3/20,dot.offsetLeft,dot.offsetTop);
		playerBall.push = Math.sqrt((dot.offsetLeft - ballDesk.offsetWidth*3/20)*(dot.offsetLeft - ballDesk.offsetWidth*3/20) + (dot.offsetTop - ballDesk.offsetWidth*3/20)*(dot.offsetTop - ballDesk.offsetWidth*3/20))/(ballDesk.offsetWidth*3/20);
//		console.log([playerBall.push,playerBall.prePushDirection]);
		
	},false);
	var game_content = document.querySelector(".gameEnd_content");
	game_content.style.width = ballDesk.width/xxxxx + "px";
	game_content.style.height = ballDesk.height/xxxxx + "px";
	game_content.style.marginLeft = ballDesk.offsetLeft + "px";
	game_content.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	game_content.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	var message = document.querySelector(".message");
	message.style.left = (container.offsetWidth - 250)/2 + "px";
	document.getElementsByClassName("last")[0].addEventListener("touchstart",function(){
		exit_per();
	},false);
	document.getElementsByClassName("start")[0].addEventListener("touchstart",function(){
		begin();
//		test();
	},false);
	document.getElementsByClassName("rank")[0].addEventListener("touchstart",function(){
		menuRankContent();
	},false);
	document.getElementsByClassName("exit")[0].addEventListener("touchstart",function(){
		exit();
	},false);
	document.getElementsByClassName("restart")[1].addEventListener("touchstart",function(){
		restart();
	},false);
	document.getElementById("conti").addEventListener("touchstart",function(){
		continueGame();
	},false);
	document.getElementsByClassName("restart")[2].addEventListener("touchstart",function(){
		returnMenu();
	},false);
	var menuRank = document.querySelector(".menuRank_content");
	menuRank.style.width = ballDesk.width/xxxxx + "px";
	menuRank.style.height = ballDesk.height/xxxxx + "px";
	menuRank.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menuRank.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menuRank.style.left = (window.innerWidth - ballDesk.offsetWidth)/2+ "px";
}
//重复适配
window.onload = function(){
	resizeScreen();
}
window.onresize = function(){
	resizeScreen();
}

function resizeScreen(){
	scale = setScreen();
	body.style.width = window.innerWidth + "px";
	body.style.height = window.innerHeight + "px";
	container.style.width = window.innerWidth  + "px";
	container.style.height = window.innerHeight  + "px";
	container.style.backgroundImage = "url(" + imgLoadArr[11].src + ")";
	ballDesk.style.backgroundImage = "url(" + imgLoadArr[0].src + ")";
	document.getElementsByTagName("html")[0].style.fontSize = window.innerWidth / 20 + "px";
	ballDesk.width = gameDeskData.widthPng;
	ballDesk.height = gameDeskData.heightPng;
	ballDesk.style.width = scale[1] + "px";
	ballDesk.style.height = scale[2] + "px";
	var proBle = document.querySelector(".proBle");
	proBle.style.width = ballDesk.offsetWidth * 0.7 + "px";
	proBle.style.height = ballDesk.offsetWidth * 0.1 + "px";
	proBle.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth * 0.15 + "px";
	proBle.style.fontSize = ballDesk.offsetWidth * 0.05 + "px";
	var strengh = document.querySelector(".strengh");
	strengh.style.display = "block";
	strengh.style.width = ballDesk.offsetWidth * 0.1 + "px";
	strengh.style.height = ballDesk.offsetWidth * 0.7 + "px";
	strengh.style.top = ballDesk.offsetHeight * 0.525 + "px";
	var drag = strengh.querySelector(".drag");
	var dragDiv = strengh.querySelector(".dragDiv");
	var close = document.querySelector(".close");
	close.style.right = ballDesk.offsetWidth*0.1 + "px";
	close.style.top = ballDesk.offsetWidth*0.1 + "px";
	var menu = document.querySelector(".menu");
	menu.style.width = ballDesk.offsetWidth*scale[0]/xxxxx + "px";
	menu.style.height = ballDesk.offsetHeight*scale[0]/xxxxx + "px";
	menu.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menu.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menu.style.left = ballDesk.offsetLeft + "px";
	var anD = document.querySelector(".JQWZan");
	anD.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth*0.5 - 59+"px";
	anD.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	anD.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	var seleMenu = document.querySelector(".seleMenu");
	seleMenu.style.left = ballDesk.offsetLeft + ballDesk.offsetWidth/2 - window.innerWidth/4 + "px";
	var game_content = document.querySelector(".gameEnd_content");
	game_content.style.width = ballDesk.width/xxxxx + "px";
	game_content.style.height = ballDesk.height/xxxxx + "px";
	game_content.style.marginLeft = ballDesk.offsetLeft + "px";
	game_content.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	game_content.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	var message = document.querySelector(".message");
	message.style.left = (container.offsetWidth - 250)/2 + "px";
	var menuRank = document.querySelector(".menuRank_content");
	menuRank.style.width = ballDesk.width/xxxxx + "px";
	menuRank.style.height = ballDesk.height/xxxxx + "px";
	menuRank.style.webkitTransform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menuRank.style.transform = "scale("+(xxxxx/scale[0])+","+(xxxxx/scale[0])+")";
	menuRank.style.left = (window.innerWidth - ballDesk.offsetWidth)/2+ "px";
}
