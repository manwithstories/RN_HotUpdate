//顶级命名空间
var mddBll = {};
//配置文件
mddBll.mddConfig = (function () {
	var mServerURL="";//http://192.168.1.139:8082";
	var mSERVER_DOMAIN="";//http://192.168.1.139:8082";
	var getSerURLWithParam=function(pSubURL)
	{
		return mServerURL+pSubURL;
	}
	return{
		kServerURL:mServerURL //根目录
		,kGetSerURLWithParam:getSerURLWithParam //获取地址
		,kSERVER_DOMAIN:mSERVER_DOMAIN//主机
	};
})();
mddBll.bll250=(function(){
	var mGet_user_qqi="/game_server/get_user_qqi/";
	var mJoin_250="/game_server/index_250/{package_id}/join_api/";
	/*
{'ok': true, 'package': {'id': 1, 'owner_id': '77781', 'remains': 4, 'create_at': '2016-11-04 15:57:30'}, 'participants': [{'uid': '77781', 'user_name': 'xiaoguang', 'avatar': 'http://some_pic', 'seq': 3}, {'uid': '77778', 'someone', 'avatar': 'http://another_pic', 'seq': 1}]}
{'ok': false, 'error': 'not_enough_index', 'msg': 'not enough index'}
可能的错误：
not_enough_index  没有足够的指数
too_slow: 太慢了
has_joined: 已经加入了
package_id_error: 错误的250指数红包id
	*/
	var mPick_250="/game_server/index_250/{package_id}/pick_api/";
	/*
{'ok': true, 'package': {'id': 1, 'owner_id': '77781', 'remains': 4, 'create_at': '2016-11-04 15:57:30'}, 'participants': [{'uid': '77781', 'user_name': 'xiaoguang', 'avatar': 'http://some_pic', 'seq': 3}, {'uid': '77778', 'someone', 'avatar': 'http://another_pic', 'seq': 1}]}
{'ok': false, 'error': 'not_enough_index', 'msg': 'not enough index'}

可能的错误:
has_picked: 已经选过了
timeout: 超时了，我们帮你选了
not_join: 没加入游戏呢，怎么选的
	*/
	var mStatus_250="/game_server/index_250/{package_id}/status_api/";
	/*
返回结果：
{'ok': true, 'status': 'has_joined', 'life_time': 20, 'winner': '77781', 'package': {'id': 1, 'owner_id': '77781', 'remains': 4, 'create_at': '2016-11-04 15:57:30'}, 'participants': [{'uid': '77781', 'user_name': 'xiaoguang', 'avatar': 'http://some_pic', 'seq': 3}, {'uid': '77778', 'someone', 'avatar': 'http://another_pic', 'seq': 1}]}
{'ok': false}

	*/
	return{
		kURLJoin_250:mJoin_250 //加入250
		,kURLPick_250:mPick_250 //选择数字
		,kURLStatus_250:mStatus_250 //获取250状态
		,kURLGet_user_qqi:mGet_user_qqi //获取亲亲指数
	};
})();
//游戏状态
mddBll.bll250_state=(function(){
	return{
		kState_has_picked:"has_picked" // 已经选过数了，等着开奖
		,kState_has_joined:"has_joined"//已经抢到座了，该选数去了
		,kState_timeout:"timeout"//超时
		,kState_not_join:"not_join"//未加入
		,kState_available:"available"//还有空座，可以去抢
		,kState_fold:"fold"//时间到了，没凑够人，
		,kState_got_luck:"got_luck"//中大奖250
		,kState_lose:"lose"//没中奖，白花50
		,kState_is_over:"is_over"//结束了的（我没参加）
		,kState_package_still_running:"package_still_running"//炸弹还没爆炸
		,kState_other:"other"//客户端自定义状态爱
	}
})();
