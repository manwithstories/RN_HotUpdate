function loadXMLDoc(method,url, callback,dataSub) {
    var xmlhttp = new XMLHttpRequest();
    var detail = "";
    var arr = [];
    for(var key in dataSub){
        var row = key + "=" + dataSub[key];
        arr.push(row);
    }
    detail = arr.join("&");
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == XMLHttpRequest.DONE ) {
           if (xmlhttp.status == 200) {
               callback(xmlhttp.responseText);
           }
           else if (xmlhttp.status == 400) {
              occMessage('There was an error 400');
           }
           else {
               occMessage('something else other than 200 was returned');
           }
        }
    };
    if(method == "GET"){
    	if(detail.length > 0){
    		url = url + "?" + detail;
    		detail = null;
    	}
    	xmlhttp.open("GET", baseURL()+url, true);
    }else if(method == "POST"){
    	xmlhttp.open("POST", baseURL()+url, true);
    }
    
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    if(window.IAObj){
    	xmlhttp.setRequestHeader("Authorization", window.IAObj.getJwt());
    }else {
    	xmlhttp.setRequestHeader("Authorization", "Bearer " + getParam('Authorization'));
    }
    xmlhttp.send(detail);
}
function baseURL(){
	if(window.IAObj){
		return window.IAObj.getBaseUrl();
	}else {
		return "http://test.engdd.com";
	}
}
function getParam(name) {
     var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if (r != null) return unescape(r[2]); return null;
}
function exit(){
	 //dir:0发起者，1接受者
    //通讯命令:0开始
    if (checkClient()) {
        var IAMsg = { cmd: "24" };
        var tJSon = JSON.stringify(IAMsg);
        //jsonz字符串
        IAObj.jsSendCmdJsonStr(tJSon);
    } else {
        alert("未定义客户端桥");
    }

}
function checkClient() {
    var rClient = false;
    if (typeof (IAObj) != "undefined") {
        rClient = true;
    } else {
        rClient = false;
    }
    return rClient;
}
