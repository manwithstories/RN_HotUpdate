//顶级命名空间
var mddBll = {};
//配置文件
mddBll.mddConfig = (function () {
	var mServerURL="";//http://192.168.1.139:8082";
	var mSERVER_DOMAIN="";//http://192.168.1.139:8082";
	var getSerURLWithParam=function(pSubURL)
	{
		return mServerURL+pSubURL;
	}
	return{
		kServerURL:mServerURL //根目录
		,kGetSerURLWithParam:getSerURLWithParam //获取地址
		,kSERVER_DOMAIN:mSERVER_DOMAIN//主机
	};
})();
//业务
mddBll.bllPastimes=(function(){
	var mGet_user_info_by_uid="/pastimes/get_user_info_by_uid/";
	return{
		//获取用户信息
		kGet_user_info_by_uid:mGet_user_info_by_uid
	};
})();
//业务逻辑
mddBll.bllBomb_package=(function(){
	var mGet_user_qqi="/game_server/get_user_qqi/";
	var mCreate_bomb_package="/game_server/bomb_package/create_bomb_package/_api/";
	var mBomb_package_state="/game_server/bomb_package/{package_id}/_api/";
	var mBomb_package_snatch="/game_server/bomb_package/{package_id}/snatch/_api/";
	var mBomb_package_snatch_list="/game_server/bomb_package/{package_id}/snatch_list/_api/";
	return{
		kURLCreate_bomb_package:mCreate_bomb_package //创建炸弹
		,kURLBomb_package_state:mBomb_package_state //查询状态
		,kURLBomb_package_snatch:mBomb_package_snatch //抢红包
		,kURLGet_user_qqi:mGet_user_qqi //获取亲亲指数
		,kBomb_package_snatch_list:mBomb_package_snatch_list //获取列表
	};
})();
//游戏状态
mddBll.bllBomb_state=(function(){
	return{
		kState_available:"available" // 可以抢     （还没结束，也没被抢完)
		,kState_nobody_comes:"nobody_comes"//很遗憾，无人抢 （已结束，没人参与）
		,kState_got_bomb:"got_bomb"//  抢到了炸弹（结果）
		,kState_got_luck:"got_luck"// 抢到了红包 （结果）
		,kState_is_over:"is_over"//  已结束（没赶上参与）
		,kState_has_snatched:"has_snatched"// 已经抢了，等结果   （还没结束）
		,kState_not_enough_index:"not_enough_index"//  没有足够的指数（没法发，或者没法抢）
		,kState_too_slow:"too_slow"// 手慢了（正好被抢完）
		,kState_bomb_still_running:"bomb_still_running"// 还有未爆炸的炸弹红包，无法创建新的
	}
})();

