

var container = document.querySelector(".container");
var ballDesk = document.querySelector("#ballDesk");
var width = 300;
var height = 300;
var master = 0;
var gameId = null;
while(width < window.innerWidth && height < window.innerHeight){
	width += 1;
	height = width/0.5625
}
ballDesk.width = width;
ballDesk.height = height;
container.style.width = window.innerWidth + "px";
container.style.height = window.innerHeight + "px";
var proBle = document.querySelector(".proBle");
proBle.style.height = ballDesk.width * 0.1 + "px";
proBle.style.width = ballDesk.width * 0.72 + "px";
proBle.style.left = ballDesk.offsetLeft + ballDesk.width*0.14 + "px";
proBle.style.display = "flex";
var close = document.querySelector(".close");
close.style.width = ballDesk.width*0.1 + "px";
close.style.height = ballDesk.width*0.1 + "px";
close.style.right = ballDesk.width * 0.1+ "px";
close.style.top = ballDesk.width * 0.1+ "px";
close.addEventListener("touchstart",function(){
	document.querySelector(".explain").style.display = "none";
},false);
document.querySelector(".score").style.fontSize = ballDesk.width*0.05 + "px";
var strengh = document.querySelector(".strengh");
strengh.style.width = ballDesk.width * 0.1 + "px";
strengh.style.height = 7*ballDesk.width*0.1 + "px";
strengh.style.top = ballDesk.height/2 +ballDesk.width*0.04 + "px";
var drag = document.querySelector(".drag");
var dragDiv = document.querySelector(".dragDiv");
dragDiv.canMove = false;
dragDiv.addEventListener("touchmove",function(e){
	e.preventDefault();
	if(ballDesk.canDrawLine == true && master == 0){
		dragDiv.top = e.touches[0].clientY - ballDesk.height/2 -ballDesk.width*0.04;
		dragDiv.top > 0?null:dragDiv.top = 0;
		dragDiv.top < 6.2*ballDesk.width*0.1?null:dragDiv.top = 6.2*ballDesk.width*0.1;
		dragDiv.style.top = dragDiv.top + "px";
		drag.style.height = dragDiv.top + "px";
		this.canMove = true;
		disDis = (dragDiv.top/(0.62*ballDesk.width))*playerBall.r*5 + playerBall.r;
		disDis < playerBall.r*1.5?disDis = playerBall.r*1.5:null;
		disDis > playerBall.r*6?disDis = playerBall.r*6:null;
	}
},false);
dragDiv.addEventListener("touchend",function(){
			var disX = ballDesk.x - playerBall.r - playerBall.x;
			var disY = ballDesk.y - playerBall.r - playerBall.y;
			var direc = angle(0, 0, -disX, -disY);
			//撞击速度，需要加入力度条
			var speedAuto = 25 * (dragDiv.offsetTop / (0.62 * ballDesk.width));
			if(speedAuto >= 1 && this.canMove == true && master == 0){
				playerBall.push = playerBall.prePush;
				playerBall.speedX = speedAuto * Math.cos(direc * Math.PI / 180);
				playerBall.speedY = speedAuto * Math.sin(direc * Math.PI / 180);
				ballDesk.canDrawLine = false;
				ballDesk.canHit = false;
				ballDesk.min = returnMinNum();
				preScore = ballIn.length;
				this.canMove = false;
				document.querySelector(".hitMenuMaster0").style.backgroundImage = "url(img/nine/xuanqu1.png)";
				document.querySelector(".master0").src = "img/nine/xuanqu1.png";
			}	
},false);

var ctx = ballDesk.getContext("2d");
var imgSrc = ["img/nine/desk.png","img/nine/QIUmu.png","img/nine/QIU1.png","img/nine/QIU2.png","img/nine/QIU3.png","img/nine/QIU4.png","img/nine/QIU5.png","img/nine/QIU6.png","img/nine/QIU7.png","img/nine/QIU8.png","img/nine/QIU9.png","img/nine/background.jpg","img/nine/yiqiu.png","img/nine/xuanqu1.png","img/nine/xuanqu2.png","img/nine/xuanqu3.png","img/nine/xuanqu4.png","img/nine/xuanqu5.png","img/nine/xuanqu6.png","img/nine/xuanqu7.png","img/nine/xuanqu8.png","img/nine/xuanqu9.png","img/nine/gan.png"];
var imgArrLoadEnd = [];
var loadNum = 0;
var imgTable = null;
var imgWhiteBall = null;
var imgYellowBall = null;
var playerBall = null;//白球对象
var scoreBallArr = [];//分数球对象
var crashClear = [];//防止连续碰撞机制
var scoreBalls = [];//进洞球
var ballR = ballDesk.width/25;//球半径
var ballAllArr = [];//包含所有球的数组;
var moca = 0.15;//桌面摩擦力
var disDis = ballR * 1.5;
var gameTimer = null;
var ballImg1 = null;
var ballImg2 = null;
var ballImg3 = null;
var ballImg4 = null;
var ballImg5= null;
var ballImg6 = null;
var ballImg7 = null;
var ballImg8 = null;
var ballImg9 = null;
var backgroundJpg = null;
var yiqiu = null;
var xuanqu1 = null;
var xuanqu2 = null;
var xuanqu3 = null;
var xuanqu4 = null;
var xuanqu5 = null;
var xuanqu6 = null;
var xuanqu7 = null;
var xuanqu8 = null;
var xuanqu9 = null;
var xuanquArr = [];
var ballIn = [];
var exp = document.querySelector(".exp");
exp.addEventListener("touchstart",function(){
	document.querySelector(".explain").style.display = "block";
},false);
var ballInlen = 0;
var gan = null;
var strengh = null;
var game = true;
var preScore = 0;
var scoreAll = 0;
var tip = "";
var ballColor = ["#D4B700","#004C94","#B23600","#680496","#C87E00","#077915","#5A003A","#060806","pink"];
var submitScore = true;
var containerSign = document.querySelector(".containerSign");
containerSign.style.width = window.innerWidth + "px";
containerSign.style.height = window.innerHeight + "px";
