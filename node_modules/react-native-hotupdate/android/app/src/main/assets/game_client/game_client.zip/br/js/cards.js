var u = navigator.userAgent;
		var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    
		function checkIAObj() {
		    var rClient = false;
		    if (typeof (IAObj) != "undefined") {
		        rClient = true;
		    } else {
		        rClient = false;
		    }
		    return rClient;
		}
		
		function getUrlParam(name) {
	        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	        var r = window.location.search.substr(1).match(reg);
	        if (r != null) return unescape(r[2]); return null;
     	}

		function getClientUserId()
		{
		    if (checkIAObj()) {
		        var tUserInfo=IAObj.getUserInfo();
		        if(isString(tUserInfo))
		        {
		            tUserInfo = eval("("+tUserInfo+")");
		        }
		        return tUserInfo["userId"];
		    }else{
		        return getUrlParam('uid');
		    }
		}

		function isString(str) {
		    return (typeof str == 'string') && str.constructor == String;
		}

		function msg(str)
		{
			if (typeof(occMessage) === "function")
			{
				occMessage(str);
			}
			else
			{
				if (checkIAObj())
				{
					doTestUi(str);
				}
				else
				{
					alert(str);
				}
			}
		}

		MyCardInfo = function()
		{
		};
		
		MyCardInfo.prototype = {
			_name: "",
			_id: "",
			_kind: "",
			_smallImage: "",
			_graySmallImage: "",
			_largeImage: "",
			_grayLargeImage: "",
			_num: 0,
			
			setName: function(value)
			{
				this._name = value;
			},
			
			getName: function()
			{
				return this._name;
			},
			
			setId: function(value)
			{
				this._id = value;
			},
			
			getId: function()
			{
				return this._id;
			},
			
			setKind: function(value)
			{
				this._kind = value;
			},
			
			getKind: function()
			{
				return this._kind;
			},
			
			setSmallImage: function(value)
			{
				this._smallImage = value;
			},
			
			getSmallImage: function()
			{
				return this._smallImage;
			},
			
			setGraySmallImage: function(value)
			{
				this._graySmallImage = value;
			},
			
			getGraySmallImage: function()
			{
				return this._graySmallImage;
			},
			
			setLargeImage: function(value)
			{
				this._largeImage = value;
			},
			
			getLargeImage: function()
			{
				return this._largeImage;
			},
			
			setGrayLargeImage: function(value)
			{
				this._grayLargeImage = value;
			},
			
			getGrayLargeImage: function()
			{
				return this._grayLargeImage;
			},
			
			setNum: function(value)
			{
				this._num = value;
			},
			
			getNum: function()
			{
				return this._num;
			}
		};
    	
    	var cards = [];

    	function initCards()
    	{
	    	cards[0] = [];
	    	cards[1] = [];
	    	cards[2] = [];
	    	
	    	for (var i = 0; i < cards.length; i++)
	    	{
	    		var card = cards[i];
	    		for (var j = 0; j < 9; j++)
	    		{
					card[j] = new MyCardInfo();
					
					card[j].setNum((i + j) % 2);
	    		}
	    	}
    	}

    	function showCardsPage()
    	{
    		showLoading();
    		hideMyCards();
    		
    		document.getElementById("myCards").style.display = "block";

			queryMyCards(1);
    	}
    	
    	function hideCardsPage()
    	{
    		document.getElementById("myCards").style.display = "none";
    	}
    	
    	function showLoading()
    	{
    		document.getElementById("loadingBar").style.display = "block";
    	}
    	
    	function hideLoading()
    	{
    		document.getElementById("loadingBar").style.display = "none";
    	}

		function buildUrl(url)
		{
			if (checkClient())
			{
				return url;
			}
			else
			{
				return "http://test.engdd.com" +
					url + "?Authorization=" + 
					"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmaXJzdF9uYW1lIjoiXHU5MGI1IiwibGFzdF9uYW1lIjoiXHU1Yjg3XHU3MGMxIiwidWlkIjoiNzc3NzciLCJjb21tdW5pdHlfaWQiOiI1OTczNSIsImhlYWRlcl91cmwiOiJodHRwczovL3Rlc3QuZW5nZGQuY29tL2ltZy9iYWQ1M2U5MC1iYTZmLTQ2NDQtOGExNS1kNzVhN2FiYjRjMWIuanBnIiwiY2hhdF9pZCI6Imdyb3VwLjQ4OTEiLCJleHAiOjE0ODc0MTU3MzIsInVzZXJfbmFtZSI6Ilx1OTBiNVx1NWI4N1x1NzBjMSJ9.k1xvcU1cOXlGIndhXKZxZ05bTfnbm0aKTTOSmFzT55g";
			}
		}
		
		function fillCardInfo(data)
		{
			for (var k = 0; k < data.cards.length; k++)
			{
				var curCard = data.cards[k];
				
				var index = curCard.index + "";
				var i = parseInt(index.substring(0, 1)) - 1;
				var j = parseInt(index.substring(1)) - 1;
				var card = cards[i][j];
				
				card.setName(curCard.name);
				card.setId(index);
				card.setKind(curCard.kind);
				card.setSmallImage(curCard.small_pict_url);
				card.setGraySmallImage(curCard.blank_small_pict_url);
				card.setLargeImage(curCard.large_pict_url);
				card.setGrayLargeImage(curCard.blank_large_pict_url);
				card.setNum(curCard.count);
			}
		}
    	
    	function queryMyCards(index)
    	{
    		if(index == 1){
    			showLoading();
    		}
    		hideMyCards();
    		
//  		var url = buildUrl("/game_server/box_package/get_my_cards/");
 		loadXMLDoc("GET", "/game_server/box_package/get_my_cards/", function(data) {
 			var result = JSON.parse(data);
				if(result.ok == true){
					//请求成功回调函数
					if (result.cards != null && result.cards.length > 0)
					{
						fillCardInfo(result);

			    		showMyCards();
			    		hideLoading();
					}
					else
					{
						msg("一张卡片都没有，快去开箱子吧。");
					}
				}else{
					//返回错误信息 occMessage(str); 为在屏幕上提示错误信息。
					msg(result.msg);
				}    			
 		}, null);
    		
			
			// doServerGetOperWithJWT_PC(url, null, 
			// 	function(data) {
			// 		if (data.ok)
			// 		{
			// 			if (data.cards != null && data.cards.length > 0)
			// 			{
			// 				fillCardInfo(data);

			// 	    		showMyCards();
			// 	    		hideLoading();
			// 			}
			// 			else
			// 			{
			// 				msg("一张卡片都没有，快去开箱子吧。");
			// 			}
			// 		}
			// 		else
			// 		{
			// 			msg("查询数据失败，请重试。");
			// 		}
			// 	}, 
			// 	function(status) {
		 //        	if (status != "success") {
		 //        		msg("查询数据失败，请重试。");
		 //        	}
			// 	}, 
			// 	function(error) {
			// 	});
    	}
    	
    	function showMyCards()
    	{
    		var ownClass = [];
    		for (var i = 0; i < cards.length; i++)
    		{
    			var card = cards[i];
    			ownClass[i] = 0;
    			for (var j = 0; j < card.length; j++)
    			{
    				var info = card[j];
    				var elImg = document.getElementById("img" + i + j);
    				var elNum = document.getElementById("num" + i + j);
    				if (info != null)
    				{
    					elImg.alt = info.getName();
    					
    					var num = info.getNum();
	    				if (num > 0)
	    				{	
	    					ownClass[i] += 1;
	    					if (elImg != null)
	    					{
	    						elImg.src = info.getSmallImage();
	    					}
	    					if (elNum != null)
	    					{
	    						elNum.innerText = num;
	    						elNum.style.background = "#ffdb14";
	    					}
	    				}
	    				else
	    				{
	    					if (elImg != null)
	    					{
	    						elImg.src = info.getGraySmallImage();
	    					}
	    					if (elNum != null)
	    					{
	    						elNum.innerText = "";
	    						elNum.style.background = "transparent";
	    					}
	    				}
    				}
    			}
    		}
    		
    		document.getElementById("cardsList").style.display = "block";
    		document.getElementById("cardsList").scrollTop = 0;
    		if(ownClass[0] < 9){
    			document.getElementById("xxf_num").innerHTML = "已收集"+ownClass[0]+"种，还差"+(9-ownClass[0])+"种";
    		}else {
    			document.getElementById("xxf_num").innerHTML = "已集齐！";
    		}
    		
    		if(ownClass[1] < 9){
    			document.getElementById("whd_num").innerHTML = "已收集"+ownClass[1]+"种，还差"+(9-ownClass[1])+"种";
    		}else {
    			document.getElementById("whd_num").innerHTML = "已集齐！";
    		}
    		
    		if(ownClass[2] < 9){
    			document.getElementById("yqh_num").innerHTML = "已收集"+ownClass[2]+"种，还差"+(9-ownClass[2])+"种";
    		}else {
    			document.getElementById("yqh_num").innerHTML = "已集齐！";
    		}
    		
    	}
    	
    	function hideMyCards()
    	{
    		document.getElementById("cardsList").style.display = "none";
    	}
    	
    	var curLargeInfo = null;
    	function showCardInfo(info)
    	{
    		curLargeInfo = info;
    		
    		var elR = document.getElementById("tdRecv");
    		var elS = document.getElementById("tdSend");
    		
    		elR.innerText = "";
    		elS.innerText = "";
    		
    		if (info != null)
    		{
    			document.getElementById("imgLarge").src = info.getLargeImage();
    			document.getElementById("imgLarge").alt = info.getName();
    		}
    		
    		document.getElementById("cardInfo").style.display = "block";
    		
    		if (info != null)
    		{
    			queryMyCardRecv(info.getId());
    			queryMyCardSend(info.getId());
    		}
    	}
    	
    	function fillMyCardRecvList(data)
    	{
    		if (data.senders != null && data.senders.length > 0)
    		{
    			var content = "";
    			for (var i = 0; i < data.senders.length; i++)
    			{
    				var sender = data.senders[i];
    				if (sender != null)
    				{
    					if (content.length > 0)
    					{
    						content += " ";
    					}
    					
    					content += sender.sender_name + "(" + sender.sum + ")";
    				}
    			}
    			document.getElementById("tdRecv").innerText = content;
    		}
    	}
    	
    	function queryMyCardRecv(index)
    	{
//  		var url = buildUrl("/game_server/box_package/get_senders/?card_index=" + index);

			loadXMLDoc("GET", "/game_server/box_package/get_senders/", function(data) {
				var result = JSON.parse(data);
				if(result.ok == true){
					//请求成功回调函数
					fillMyCardRecvList(result);
				}				
			}, {
				card_index:index
			});

			// doServerGetOperWithJWT_PC(url, null, 
			// 	function(data) {
			// 		if (data.ok)
			// 		{
			// 			fillMyCardRecvList(data);
			// 		}
			// 	}, 
			// 	function(status) {
			// 	}, 
			// 	function(error) {
			// 	});
    	}
    	
    	function fillMyCardSendList(data)
    	{
    		if (data.receivers != null && data.receivers.length > 0)
    		{
    			var content = "";
    			for (var i = 0; i < data.receivers.length; i++)
    			{
    				var sender = data.receivers[i];
    				if (sender != null)
    				{
    					if (content.length > 0)
    					{
    						content += " ";
    					}
    					if(sender.sender_name){
    						content += sender.sender_name + "(" + sender.sum + ")";
    					}else {
    						content += sender.receiver_phone + "(" + sender.sum + ")";
    					}
//  					content += sender.sender_name + "(" + sender.count + ")";
    				}
    			}
    			document.getElementById("tdSend").innerText = content;
    		}
    	}
    	
    	function queryMyCardSend(index)
    	{
//  		var url = buildUrl("/game_server/box_package/get_receivers/?card_index=" + index);

			loadXMLDoc("GET", "/game_server/box_package/get_receivers/", function(data) {
				var result = JSON.parse(data);
				if(result.ok == true){
					//请求成功回调函数
					fillMyCardSendList(result);
				}				
			}, {
				card_index : index
			});

			// doServerGetOperWithJWT_PC(url, null,
			// 	function(data) {
			// 		if (data.ok)
			// 		{
			// 			fillMyCardSendList(data);
			// 		}
			// 	}, 
			// 	function(status) {
			// 	}, 
			// 	function(error) {
			// 	});
    	}
    	
    	function hideCardInfo()
    	{
    		document.getElementById("cardInfo").style.display = "none";
    		//重新刷新card_list
    		queryMyCards(2);
    	}
				
		function clickCardItem(event)
		{
			event = event ||window.event;
			var target = event.target||event.srcElement;
			if (target != null)
			{
				var id = target.id + "";
				var re = /[img|num]([0-9]{2})/;
				var r = id.match(re);
				if (r != null)
				{
					try
					{
						var i = parseInt(RegExp.$1.substring(0, 1));
						var j = parseInt(RegExp.$1.substring(1));
						var info = cards[i][j];
						if (info != null)
						{
							if (info.getNum() > 0)
							{
								showCardInfo(info);
							}
							else
							{
								msg("您还没有这张卡，快去开箱子吧。");
							}
						}
					}
					catch(e)
					{
					}
				}
			}
		}
		
		function sendToFirend()
		{
			var elPhone = document.getElementById("inputPhone");
			var phone = elPhone.value;
			
			var reChinese = /^[1][1-9][0-9]{9}$/;
			var reUsa = /^\d{10}$/;
			var reFrance = /^\d{9}$/;

			if (reChinese.test(phone) || 
				reUsa.test(phone) ||
				reFrance.test(phone))
			{
				var cardIndex = null;
				if (curLargeInfo != null)
				{
					cardIndex = curLargeInfo.getId();
				}

				if (cardIndex != null)
				{
					var postData = {
						mobile: phone,
						card_index: parseInt(cardIndex)
					};
					
//					var url = buildUrl("/game_server/box_package/send_to/");
					
					loadXMLDoc("POST", "/game_server/box_package/send_to/", function(data) {
						var result = JSON.parse(data);
						if(result.ok == true){
							//请求成功回调函数
							sendSms(phone);
							msg("赠送卡片成功！");
						}else {
							msg(result.msg[0]);
						}
						
					}, postData);

					// doServerOperWithJWT_PC(url, postData, 
					// 	function(data) {
					// 		if (data.ok)
					// 		{
					// 			msg("赠送卡片成功！");
					// 		}
					// 		sendSms(phone);
					// 	},
					// 	function(status) {
					// 	},
					// 	function(error) {
					// 	});
				}
			}			
			else
			{
				msg("手机号码无效！");
			}
		}
		
		function sendSms(phone)
		{
			var cardIndex = curLargeInfo.getId();
			var uid = getClientUserId();
	
			var content = "我送了你一张新春祝福卡，点击领取！http://v3.qinqinwojia.cn/game_server/box_package/get_card/"+getClientUserId()+"/"+phone+"/"+cardIndex+"/";
			var elSms = document.getElementById("aSms");
			if (isiOS)
			{
				elSms.href = "sms:" + phone + "&body=" +
					content;
			}
			else
			{
				elSms.href = "sms:" + phone + "?body=" +
					content;
			}
			elSms.click();
		}
		function newCard(){
			loadXMLDoc("GET","/game_server/box_package/get_new_gift/",function(data){
				var back = JSON.parse(data);
				if(back.ok == true){
					for(var i = 0 ; i < back.gifts.length; i ++){
						receivecard(back.gifts[i].sender_name,back.gifts[i].card.large_pict_url);
					}
				}else {
					occMessage(back.msg)
				}
			},{})
		}
    	
    	newCard();
    	initCards();