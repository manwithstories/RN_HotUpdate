﻿/// <reference path="../js/jquery.js" />
//alert("test load!");
//app通用方法
//通用方法(日志方法)
function myLoger(msg) {
    alert(msg);
}
//必须方法
function myMsg(msg) {
    alert(msg);
}
//服务器操作
function doServerOper(pUrl, pData, sucCallBack, compCallBack, errCallBack) {
    var testURL = pUrl;
    var siginURL = window.IAObj.getBaseUrl() + IAObj.getClientSingnUrl(testURL);
    var fromData = pData;
    $.ajax({
        //提交数据的类型 POST GET
        type: "POST",
        //提交的网址
        url: siginURL,
        //提交的数据
        data: fromData,
        //返回数据的格式
        datatype: "html",//"xml", "html", "script", "json", "jsonp", "text".
        //在请求之前调用的函数
        beforeSend: function () {
            IAObj.jsLog("Param:" + JSON.stringify(fromData));
        },
        //成功返回之后调用的函数
        success: function (data) {
            IAObj.jsLog("URL:" + siginURL + ",Data:" + JSON.stringify(data));
            sucCallBack(data);

        },
        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //alert(XMLHttpRequest.responseText);
            //alert(textStatus);
            //HideLoading();
            IAObj.jsLog("URL:" + siginURL + ",STATUS:" + textStatus);
            compCallBack(textStatus);
        },
        //调用出错执行的函数
        error: function (error) {
            //请求出错处理
            IAObj.jsLog("URL:" + siginURL + ",ERR:" + JSON.stringify(error));
            errCallBack(error);

        }
    });
}
//服务器操作
function doServerGetOper(pUrl, pData, sucCallBack, compCallBack, errCallBack) {
    var testURL = pUrl;
    var siginURL = window.IAObj.getBaseUrl() + IAObj.getClientSingnUrl(testURL);
    var fromData = pData;
    $.ajax({
        //提交数据的类型 POST GET
        type: "GET",
        //提交的网址
        url: siginURL,
        //提交的数据
        data: fromData,
        //返回数据的格式
        datatype: "html",//"xml", "html", "script", "json", "jsonp", "text".
        //在请求之前调用的函数
        beforeSend: function () {
            IAObj.jsLog("Param:" + JSON.stringify(fromData));
        },
        //成功返回之后调用的函数
        success: function (data) {
            IAObj.jsLog("URL:" + siginURL + ",Data:" + JSON.stringify(data));
            sucCallBack(data);

        },
        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //alert(XMLHttpRequest.responseText);
            //alert(textStatus);
            //HideLoading();
            IAObj.jsLog("URL:" + siginURL + ",STATUS:" + textStatus);
            compCallBack(textStatus);
        },
        //调用出错执行的函数
        error: function (error) {
            //请求出错处理
            IAObj.jsLog("URL:" + siginURL + ",ERR:" + JSON.stringify(error));
            errCallBack(error);

        }
    });
}
//不加密的url
function doServerGetOperUnsign(pUrl, pData, sucCallBack, compCallBack, errCallBack) {
    var testURL = pUrl;
    var siginURL = window.IAObj.getBaseUrl() + IAObj.getClientSingnUrl(testURL);
    var fromData = pData;
    $.ajax({
        //提交数据的类型 POST GET
        type: "GET",
        //提交的网址
        url: siginURL,
        //提交的数据
        data: fromData,
        //返回数据的格式
        datatype: "html",//"xml", "html", "script", "json", "jsonp", "text".
        //在请求之前调用的函数
        beforeSend: function () {
            IAObj.jsLog("Param:" + JSON.stringify(fromData));
        },
        //成功返回之后调用的函数
        success: function (data) {
            IAObj.jsLog("URL:" + siginURL + ",Data:" + JSON.stringify(data));
            sucCallBack(data);

        },
        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //alert(XMLHttpRequest.responseText);
            //alert(textStatus);
            //HideLoading();
            IAObj.jsLog("URL:" + siginURL + ",STATUS:" + textStatus);
            compCallBack(textStatus);
        },
        //调用出错执行的函数
        error: function (error) {
            //请求出错处理
            IAObj.jsLog("URL:" + siginURL + ",ERR:" + JSON.stringify(error));
            errCallBack(error);

        }
    });
}
//jwt请求
function doServerOperWithJWT(pUrl, pData, sucCallBack, compCallBack, errCallBack) {
    var testURL = pUrl;
    var siginURL = window.IAObj.getBaseUrl() + testURL;//IAObj.getClientSingnUrl(testURL);
    var tJwt=getJWt();
    var fromData = pData;
    $.ajax({
        //提交数据的类型 POST GET
        type: "POST",
        //提交的网址
        url: siginURL,
        //提交的数据
        data: fromData,
        //返回数据的格式
        datatype: "html",//"xml", "html", "script", "json", "jsonp", "text".
        //添加额外的请求头
        headers : {'Access-Control-Allow-Origin':'*','Authorization':tJwt},
        //在请求之前调用的函数
        beforeSend: function () {
            IAObj.jsLog("Param:" + JSON.stringify(fromData));
        },
        //成功返回之后调用的函数
        success: function (data) {
            IAObj.jsLog("URL:" + siginURL + ",Data:" + JSON.stringify(data));
            sucCallBack(data);

        },
        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //alert(XMLHttpRequest.responseText);
            //alert(textStatus);
            //HideLoading();
            IAObj.jsLog("URL:" + siginURL + ",STATUS:" + textStatus);
            compCallBack(textStatus);
        },
        //调用出错执行的函数
        error: function (error) {
            //请求出错处理
            IAObj.jsLog("URL:" + siginURL + ",ERR:" + JSON.stringify(error));
            errCallBack(error);

        }
    });
}
//jwt请求
function doServerGetOperWithJWT(pUrl, pData, sucCallBack, compCallBack, errCallBack) {
    var testURL = pUrl;
    var siginURL = window.IAObj.getBaseUrl() + testURL;//IAObj.getClientSingnUrl(testURL);
    var tJwt=getJWt();
    var fromData = pData;
    $.ajax({
        //提交数据的类型 POST GET
        type: "GET",
        //提交的网址
        url: siginURL,
        //提交的数据
        data: fromData,
        //返回数据的格式
        datatype: "html",//"xml", "html", "script", "json", "jsonp", "text".
        //添加额外的请求头
        headers : {'Access-Control-Allow-Origin':'*','Authorization':tJwt},
        //在请求之前调用的函数
        beforeSend: function () {
            IAObj.jsLog("Param:" + JSON.stringify(fromData));
        },
        //成功返回之后调用的函数
        success: function (data) {
            IAObj.jsLog("URL:" + siginURL + ",Data:" + JSON.stringify(data));
            sucCallBack(data);

        },
        //调用执行后调用的函数
        complete: function (XMLHttpRequest, textStatus) {
            //alert(XMLHttpRequest.responseText);
            //alert(textStatus);
            //HideLoading();
            IAObj.jsLog("URL:" + siginURL + ",STATUS:" + textStatus);
            compCallBack(textStatus);
        },
        //调用出错执行的函数
        error: function (error) {
            //请求出错处理
            IAObj.jsLog("URL:" + siginURL + ",ERR:" + JSON.stringify(error));
            errCallBack(error);

        }
    });
}