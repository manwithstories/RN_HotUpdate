/*
实体
*/
mddBll.bll250.participant=function(pParticipants)
{
	this.uid=pParticipants["uid"];
	this.user_name=pParticipants["user_name"];
	this.avatar=pParticipants["avatar"];
	this.seq=pParticipants["seq"];
    if(typeof(pParticipants["step"])!="undefined")
    {
        this.step=pParticipants["step"];//位置
    }else{
        this.step=-100;//位置
    }
	return this;
}
mddBll.bll250.package=function(pPackage)
{
	this.id=pPackage["id"];
	this.owner_id=pPackage["owner_id"];
	this.remains=pPackage["remains"];
	this.create_at=pPackage["create_at"];
	return this;
}
mddBll.bll250.bll250BigSuc = function (pObj) {
    this.ok = pObj["ok"];//编号
    this.package = new mddBll.bll250.package(pObj["package"]);
    this.participants = new Array();
    for (var i = 0; i < pObj["participants"].length; i++) {
        var participant = pObj["participants"][i];
        this.participants.push(new mddBll.bll250.participant(participant));
    }
    return this;
};
mddBll.bll250.bll250BigErr = function (pObj) {
    this.ok = pObj["ok"];//编号
    this.error = pObj["error"];
    this.msg = pObj["msg"];
    return this;
};
mddBll.bll250.bll250Status = function (pObj) {
    this.ok = pObj["ok"];//编号
    this.status=pObj["status"];//状态
    this.life_time=pObj["life_time"];//剩余时间
    this.winner=pObj["winner"];//赢的人
    if(typeof(pObj["winner_position"])!="undefined")
    {
        this.winner_position=pObj["winner_position"];//赢得位置
    }else{
        this.winner_position=undefined;
    }
    this.package = new mddBll.bll250.package(pObj["package"]);
    this.participants = new Array();
    for (var i = 0; i < pObj["participants"].length; i++) {
        var participant = pObj["participants"][i];
        this.participants.push(new mddBll.bll250.participant(participant));
    }
    return this;
};