window.onresize = function() {
	setScreen();
}
function setHelp(){
	var helpDiv = document.querySelector(".gamehelp");
	helpDiv.style.height = window.innerHeight + "px";
}
function setLarge(){
	var largeDiv = document.querySelector(".largeNum");
	largeDiv.style.height = window.innerHeight + "px";
}
var presize = window.innerWidth;
function setScreen() {
	document.getElementsByTagName("html")[0].style.fontSize = window.innerWidth / 20 + "px";
	document.getElementById("container").style.height = window.innerHeight + "px";
	setHelp();
	setLarge();
}
window.onload = function() {
	setScreen();
}
setScreen();
setTimeout(function(){
	if(presize  !=  window.innerWidth){
		setScreen();
	} 
},1000);