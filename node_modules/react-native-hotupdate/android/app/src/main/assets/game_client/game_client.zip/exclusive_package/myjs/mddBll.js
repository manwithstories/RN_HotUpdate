﻿//顶级命名空间
var mddBll = {};
