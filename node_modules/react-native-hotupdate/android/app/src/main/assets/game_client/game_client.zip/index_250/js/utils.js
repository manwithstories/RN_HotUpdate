function doGetQqi(callback)
{
    var get_user_qqi_url = "/game_server/get_user_qqi/";
    doServerGetOperWithJWT_PC(get_user_qqi_url, {"csrfmiddlewaretoken":  getCookie('csrftoken')}, function (data) {
        try{
            var resCode = data["ok"];
            if (resCode == true) {
                    var userMoney = parseInt(data["balance"]);
                    callback(userMoney);
            }
            else {
                myUIAlert(JSON.stringify(data));
            }
        } catch (e) {
            myUIAlert("url:"+get_user_qqi_url+"err:"+JSON.stringify(e));
        }

    }, function (textStatus) {
        myClientLog(textStatus);
    }, function (error) {
         myUIAlert("url:"+get_user_qqi_url+"err:"+JSON.stringify(error));
    });

}
