function animate() {
	ctx.clearRect(0, 0, ballDesk.width, ballDesk.height);
	//绘制桌子
//	for(var i = 0 ; i <scoreBalls.length;i++){
//		scoreBalls[i].move();
//	}
	ctx.beginPath();
	jugeCraAll();
	drawPlayer();
	drawScoreBall();
	drawTipLine();
	gameEnd();
	getScore();
	score();
	ctx.closePath();
}
//预加载
function preLoading(func,positions) {
	var wrap = document.querySelector(".wrap");
	var floadp = document.querySelector(".floadp");
	wrap.style.left = (window.innerWidth-20)/2 + "px";
	wrap.style.top = "40%";
//	wrap.style.display = "block";
	
	for(var i = 0; i < imgSrc.length; i++) {
		var img = new Image();
		img.src = imgSrc[i];
		imgArrLoadEnd.push(img);
		img.onload = function() {
			loadNum++;
			floadp.innerHTML = parseInt((loadNum/imgSrc.length)*100) + "%";
			if(loadNum == imgSrc.length) {
				wrap.style.display = "none";
				//图片资源加载完毕
				imgTable = imgArrLoadEnd[0];
				imgWhiteBall = imgArrLoadEnd[1];
				ballImg1 = imgArrLoadEnd[2];
				ballImg2 = imgArrLoadEnd[3];
				ballImg3 = imgArrLoadEnd[4];
				ballImg4 = imgArrLoadEnd[5];
				ballImg5 = imgArrLoadEnd[6];
				ballImg6 = imgArrLoadEnd[7];
				ballImg7 = imgArrLoadEnd[8];
				ballImg8 = imgArrLoadEnd[9];
				ballImg9 = imgArrLoadEnd[10];
				backgroundJpg = imgArrLoadEnd[11];
				yiqiu = imgArrLoadEnd[12];
				xuanqu1 = imgArrLoadEnd[13];
				xuanquArr.push(xuanqu1);
				xuanqu2 = imgArrLoadEnd[14];
				xuanquArr.push(xuanqu2);
				xuanqu3 = imgArrLoadEnd[15];
				xuanquArr.push(xuanqu3);
				xuanqu4 = imgArrLoadEnd[16];
				xuanquArr.push(xuanqu4);
				xuanqu5 = imgArrLoadEnd[17];
				xuanquArr.push(xuanqu5);
				xuanqu6 = imgArrLoadEnd[18];
				xuanquArr.push(xuanqu6);
				xuanqu7 = imgArrLoadEnd[19];
				xuanquArr.push(xuanqu7);
				xuanqu8 = imgArrLoadEnd[20];
				xuanquArr.push(xuanqu8);
				xuanqu9 = imgArrLoadEnd[21];
				xuanquArr.push(xuanqu9);
				gan = imgArrLoadEnd[22];
				createWhite(100, 100, ballR);
				createScoreBall(positions);
				ballAllArr.push(playerBall);
				ballAllArr = ballAllArr.concat(scoreBallArr);
				ballDesk.style.backgroundImage = "url(" + imgTable.src + ")";
				container.style.backgroundImage = "url(" + backgroundJpg.src + ")";
				document.querySelector(".hitMenuMaster0").style.display = "block";
				document.querySelector(".proBle").style.left = ballDesk.offsetLeft + ballDesk.offsetWidth*0.15 + "px";
				document.querySelector(".strengh").style.display = "block";
				document.querySelector(".proBle").style.display = "flex";
				
				hitFunc();
				makeTipLine();
				createCoreBall();
				func();
			}
		}
	}
}
//得分球动画
function occMessage(str,color){
	var animateDiv = document.querySelector(".animate_getScore");
	animateDiv.innerHTML = str;
	animateDiv.style.display = "block";
	animateDiv.style.color = color;
	var bottom = 10;
	var opacity = 1;
	animateDiv.timer = setInterval(function(){
		bottom += bottom*0.05;
		opacity -= 0.03;
		animateDiv.style.bottom = bottom + "%";
		animateDiv.style.opacity = opacity;
		if(opacity <= 0){
			clearInterval(animateDiv);
			animateDiv.timer = null;
			animateDiv.style.bottom = "10%";
			animateDiv.style.opacity = 1;
			animateDiv.style.display = "none";
		}
	},30)
}
var hitMenuMaster0 = document.querySelector(".hitMenuMaster0");
var master0 = document.querySelector(".master0");
hitMenuMaster0.addEventListener("touchstart",function(){
	if(master == 0){
		master0.style.display = "block";	
	}
},false);
master0.addEventListener("touchend",function(){
	if(master == 0){
		this.style.display = "none";
	}
},false);
master0.addEventListener("touchstart",function(e){
	if(master == 0){
		var x = e.touches[0].clientX ;
		var y = e.touches[0].clientY ;
		var centerX = this.offsetLeft + this.offsetWidth/2;
		var centerY = this.offsetTop + this.offsetHeight/2;
		var hitAngle = angle(centerX,centerY,x,y);
		var menuDis = Math.sqrt((x-centerX)*(x-centerX) + (y-centerY)*(y-centerY));
		var r = this.offsetWidth/6;
		console.log(x);
		if(menuDis <= r ) {
				playerBall.prePush = 0;
				this.src = xuanqu1.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu1.src+")";
			} else if(menuDis > r  && hitAngle <= 22.5 && hitAngle > -22.5) {
				playerBall.prePush = 3;
				this.src = xuanqu8.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu8.src+")";
			} else if(menuDis > r  && hitAngle >= 22.5 && hitAngle < 67.5) {
				playerBall.prePush = 4;
				this.src = xuanqu9.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu                              .src+")";
			} else if(menuDis > r && hitAngle >= 67.5 && hitAngle < 112.5) {
				playerBall.prePush = 5;
				this.src = xuanqu2.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu2.src+")";
			} else if(menuDis > r  && hitAngle >= 112.5 && hitAngle < 157.5) {
				playerBall.prePush = 6;
				this.src = xuanqu3.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu3.src+")";
			} else if(menuDis > r  && hitAngle >= 157.5 && hitAngle < 202.5) {
				playerBall.prePush = 7;
				this.src = xuanqu4.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu4.src+")";
			} else if(menuDis > r  && hitAngle >= 202.5 && hitAngle < 247.5) {
				playerBall.prePush = 8;
				this.src = xuanqu5.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu5.src+")";
			} else if(menuDis > r  && hitAngle >= -67.5 && hitAngle < -22.5) {
				playerBall.prePush = 2;
				this.src = xuanqu7.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu7.src+")";
			} else if(menuDis > r  && hitAngle >= 247.5) {
				playerBall.prePush = 1;
				this.src = xuanqu6.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu6.src+")";
			} else if(menuDis > r  && hitAngle < -67.5) {
				playerBall.prePush = 1;
				this.src = xuanqu6.src;
				hitMenuMaster0.style.backgroundImage = "url("+xuanqu6.src+")";
			}
	}
},false);
function joinGame(index){
	master = index;
	loadXMLDoc('/game_server/billiards/create_game/', function(data){
  		var result = JSON.parse(data);
  		if(result["ok"] == true){
  			gameId = result.game.id;
	  		console.log(result.init_positions);				
	  		document.querySelector(".containerSign").style.display = "none";
			document.querySelector(".container").style.display = "block";
			start(result.init_positions);
  		}else if(result["error"] == "not_enough_qqi") {
  			alert("指数不足");
  		}
	},{})
}
function loadXMLDoc(url, callback,dataSub) {
    var xmlhttp = new XMLHttpRequest();
    var detail = "";
    var arr = [];
    for(var key in dataSub){
        var row = key + "=" + dataSub[key];
        arr.push(row);
    }
    detail = arr.join("&");
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == XMLHttpRequest.DONE ) {
           if (xmlhttp.status == 200) {
               callback(xmlhttp.responseText);
           }
           else if (xmlhttp.status == 400) {
              alert('There was an error 400');
           }
           else {
               alert('something else other than 200 was returned');
           }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    if(window.IAObj){
    	xmlhttp.setRequestHeader("Authorization", window.IAObj.getJwt());
    }else {
    	xmlhttp.setRequestHeader("Authorization", "Bearer " + getParam('Authorization'));
    }
    xmlhttp.send(detail);
}
function getParam(name) {
     var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if (r != null) return unescape(r[2]); return null;
}
function exit(){
	 //dir:0发起者，1接受者
    //通讯命令:0开始
    if (checkClient()) {
        var IAMsg = { cmd: "24" };
        var tJSon = JSON.stringify(IAMsg);
        //jsonz字符串
        IAObj.jsSendCmdJsonStr(tJSon);
    } else {
        alert("未定义客户端桥");
    }

}
function checkClient() {
    var rClient = false;
    if (typeof (IAObj) != "undefined") {
        rClient = true;
    } else {
        rClient = false;
    }
    return rClient;
}
