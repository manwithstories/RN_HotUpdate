﻿/// <reference path="../js/jquery-1.9.1.min.js" />
//扩展地址栏方法
//兼容一下
(function ($) {
    $.getUrlParam=jQuery.getUrlParam
     = function (name) {
         var reg
          = new RegExp("(^|&)" +
          name + "=([^&]*)(&|$)");
         var r
          = window.location.search.substr(1).match(reg);
         if (r != null) return unescape(r[2]); return null;
     },
    //修改参数
   $.changeURLPar = jQuery.changeURLPar = function (destiny, par, par_value) {
        //changeURLPar(test, 'id', 99); // http://www.huistd.com/?id=99&ttt=3
        //function changeURLPar(destiny, par, par_value) {
        //debugger;
        var pattern = par + '=([^&]*)';
        var replaceText = par + '=' + par_value;
        if (destiny.match(pattern)) {
            var tmp = '/\\' + par + '=[^&]*/';
            tmp = destiny.replace(eval(tmp), replaceText);
            return (tmp);
        }
        else {
            if (destiny.match('[\?]')) {
                return destiny + '&' + replaceText;
            }
            else {
                return destiny + '?' + replaceText;
            }
        }
        return destiny + '\n' + par + '\n' + par_value;
        //}
    },
    //获取站点根目录
    $.getMddRootPath = jQuery.getMddRootPath = function () {
        var strFullPath = window.document.location.href;
        var strPath = window.document.location.pathname;
        var pos = strFullPath.indexOf(strPath);
        var prePath = strFullPath.substring(0, pos);
        var postPath = strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
        //        alert(prePath + postPath+"/FootRingWeb/");
        //return (prePath + postPath+"/FootRingWeb/")
        return (prePath + postPath)
    },
    //意外重载
   $.getMddRootPath = window.getMddRootPath = function () {
        var strFullPath = window.document.location.href;
        var strPath = window.document.location.pathname;
        var pos = strFullPath.indexOf(strPath);
        var prePath = strFullPath.substring(0, pos);
        var postPath = strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
        //        alert(prePath + postPath+"/FootRingWeb/");
        //return (prePath + postPath+"/FootRingWeb/")
        return (prePath + postPath)
    },
    //弹出日志
    $.getMddToast=jQuery.getMddToast = function (tag, msg) {
        alert(tag + ":" + msg);
    },
    $.focusblur = jQuery.focusblur = function (focusid) {
        var focusblurid = $(focusid);
        var defval = focusblurid.val();
        focusblurid.focus(function () {
            var thisval = $(this).val();
            if (thisval == defval) {
                $(this).val("");
            }
        });
        focusblurid.blur(function () {
            var thisval = $(this).val();
            if (thisval == "") {
                $(this).val(defval);
            }
        });

    },
    jQuery.fn.extend({
        limiter: function (limit, elem) {
            $(this).on("keyup focus", function () {
                /*
                var elem = $("#chars");
                $("#text").limiter(100, elem);
                */
                setCount(this, elem);
            });
            function setCount(src, elem) {
                var chars = src.value.length;
                if (chars > limit) {
                    src.value = src.value.substr(0, limit);
                    chars = limit;
                }
                elem.html(limit - chars);
            }
            setCount($(this)[0], elem);
        }
    });
})(jQuery);

